#include "i2c_config.h"
#include "i2c_core.h"


static void delay_us( int t )
{
		volatile int tt;
		for( ; t; t -- )
			for( tt = 0 ; tt < 8; tt ++ )
			;
}
void SYS_I2C_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  RCC_AHB1PeriphClockCmd( RCC_I2C_SCL , ENABLE);
  RCC_AHB1PeriphClockCmd( RCC_I2C_SDA , ENABLE);
    
  GPIO_InitStructure.GPIO_Pin = PIN_I2C_SCL ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  
  GPIO_Init(GPIO_PORT_I2C_SCL, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = PIN_I2C_SDA ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  
  GPIO_Init(GPIO_PORT_I2C_SDA, &GPIO_InitStructure);
 
  I2C_CLK_HIGH();
  I2C_DATA_HIGH();
}
static void I2C_Start(void)
{
    I2C_CLK_HIGH();
    delay_us(20);
    I2C_DATA_LOW();
    delay_us(20);
    I2C_CLK_LOW();
    delay_us(20);
    I2C_DATA_HIGH();
    delay_us(20);
}

static void I2C_Stop(void)
{
    I2C_DATA_LOW();
    delay_us(20);
    I2C_CLK_HIGH();
    delay_us(20);
    I2C_DATA_HIGH();
    delay_us(20);
}

static void I2C_nack( void )
{
    I2C_CLK_LOW();
    delay_us(20);
    I2C_DATA_HIGH();
    delay_us(20);
    I2C_CLK_HIGH();
    delay_us(20);
    I2C_CLK_LOW();
    delay_us(20);
}

static void I2C_ack( void )
{
    I2C_CLK_LOW();
    delay_us(20);
    I2C_DATA_LOW();
    delay_us(20);
    I2C_CLK_HIGH();
    delay_us(20);
    I2C_CLK_LOW();
    delay_us(20);
}

static void I2C_sendbyte( unsigned char  I2CSendData )
{
    unsigned char  i;
    
    for (i = 0;i < 8;i++)
    {
        if ( I2CSendData & 0x80 )
            I2C_DATA_HIGH();
        else
            I2C_DATA_LOW();
        delay_us(20);
        I2C_CLK_HIGH();
        delay_us(20);
        
        I2CSendData <<= 1; 
        I2C_CLK_LOW();
        delay_us(20);
    }
}
static unsigned char I2C_readbyte( void )
{
    unsigned char i;
    unsigned char ucRDData = 0;

    I2C_DATA_HIGH();

    for (i = 0;i < 8;i++)
    {
        I2C_CLK_HIGH();
        ucRDData <<= 1;
        delay_us(20);
        if (I2C_DATA_IN())
            ucRDData++;

        I2C_CLK_LOW();
        delay_us(20);
    }
    return(ucRDData);
}
static unsigned char ReceiveACK( void )
{
    unsigned char nakflag;
    I2C_DATA_HIGH();
    delay_us(20);
    I2C_CLK_HIGH();
    delay_us(20);
    nakflag = I2C_DATA_IN();
    I2C_CLK_LOW();
    delay_us(20);
    return nakflag;
}

unsigned char I2C_Write( unsigned char slave_add, unsigned char I2CAddress, unsigned char *I2CData, unsigned char size )
{
		unsigned char i;
	
    I2C_Start();

    I2C_sendbyte( slave_add << 1 );
    if( ReceiveACK() )
    {
      I2C_Stop();
      return 0;
    };

    I2C_sendbyte(I2CAddress); 
    if( ReceiveACK() )
    {
      I2C_Stop();
      return 0;
    };

		for( i = 0 ; i < size; i ++ )
		{
			I2C_sendbyte(*I2CData++);
			if( ReceiveACK() )
					break;
		}

    I2C_Stop(); 
    return i;
}

unsigned char I2C_Read( unsigned char slave_add, unsigned char I2CAddress, unsigned char *I2CData, unsigned char size )
{
		unsigned char i;
	
    I2C_Start(); 

    I2C_sendbyte( slave_add << 1 );
    if( ReceiveACK() )
    {
      I2C_Stop();
      return 0;
    };

    I2C_sendbyte(I2CAddress); 
    if( ReceiveACK() )
    {
      I2C_Stop();
      return 0;
    };

    I2C_Start();

    I2C_sendbyte( (slave_add<<1) | 1 );
    if( ReceiveACK() )
    {
      I2C_Stop();
      return 0;
    };

		for( i = 0 ; i< size; i ++ )
		{
			*I2CData++ = I2C_readbyte();
			
			if( i+1 == size )
				I2C_nack();
			else
				I2C_ack();
		}

    I2C_Stop();

    return  i;
}

