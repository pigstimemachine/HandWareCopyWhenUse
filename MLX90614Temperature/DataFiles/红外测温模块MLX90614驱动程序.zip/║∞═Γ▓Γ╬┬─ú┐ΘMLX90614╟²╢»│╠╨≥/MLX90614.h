#ifndef __MLX90614_H__
#define __MLX90614_H__

int mlx90614_read_in( void );

int mlx90614_read_out( void );

#endif


