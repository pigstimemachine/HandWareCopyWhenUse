#ifndef __GPIO_H
#define	__GPIO_H


#include "stm32f10x.h"


void GPIO_Config( void );


#endif /* __GPIO_H */
