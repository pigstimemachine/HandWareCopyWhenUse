#include "lib.h"
CanBufTypeDef CANRXBUF[RX_MAX_NUM];
CanBufTypeDef CANTXBUF[TX_MAX_NUM];
u16 Material=SampleMaterial,ModeSwitch=SampleModeSwitch;
LINK_LIST CANTxLinkList;
LINK_LIST CANRxLinkList; 
CAN_DATA  CANRxInfo,CANTxInfo;
WELDINGPARA_DATA ParaData;
HEARTBEAT_DATA      HeartBeatData;
FEEDBACK_DATA       FeedBackData;
STATUS              Status;
SWING_START         SwingStart;
CAN_TX_FLAG         CanTxFlag;
ECANID_INTERNAL     CanID;
STATUS_COUNT        StatusCount;
u8 ErrorAlert=NULL;
ECANID_INTERNAL ReceiveID;
ECANID_INTERNAL TransmitID0;
ECANID_INTERNAL TransmitID1;
ECANID_INTERNAL TransmitID2;

ECANID_INTERNAL ReceiveID0;
ECANID_INTERNAL ReceiveID1;
ECANID_INTERNAL ReceiveID2;
#define SelFunc(x)  (x==0?0xa5:0x5a)
#define EdgeFunc(x) (x==RightDir?0xAA:0x55)
#define AngleFunc(x) (x-1)
#define SourceTypeNum      2
#define MaxGunNum          2
#define SourceMotorCtrl    0													
#define SourceDPS500			 1
#define TvlAdjSpeedNum     9 

static void RefreshData(u8 Item)
{	
  ((PARA_STRUCT*)&TravelPara)[Item].ParaValue=((PARA_STRUCT*)&TravelPara)[Item].TransmitValue*((PARA_STRUCT*)&TravelPara)[Item].paraA
	                                             +((PARA_STRUCT*)&TravelPara)[Item].paraB;
}	

const u16 _AddrSel[SourceTypeNum][MaxGunNum]={
  {LeadMotorCtrlAddr,TrailMotorCtrlAddr},
	{LeadDPS500Addr,TrailDPS500Addr},	
};	

static void CreateID(void)
{
	u8 i;
	RCC->APB2ENR|=1<<4;     //ʹ��PORTCʱ��
	GPIOC->CRL&=0xFFFF0FFF;	//PC3���ó�����
	GPIOC->CRL|=0x00008000;	
	
  TransmitID0.target=MainCtrlAddr;
	TransmitID1.target=_AddrSel[SourceDPS500][IdSelect];
	TransmitID2.target=BroadcastAddr;
	
	TransmitID0.source=_AddrSel[SourceMotorCtrl][IdSelect];
	TransmitID1.source=_AddrSel[SourceMotorCtrl][IdSelect];
	TransmitID2.source=_AddrSel[SourceMotorCtrl][IdSelect];
	
	ReceiveID0.source=MainCtrlAddr;
	ReceiveID1.source=_AddrSel[SourceDPS500][IdSelect];
	ReceiveID2.source=MainCtrlAddr;
	
	ReceiveID0.target=_AddrSel[SourceMotorCtrl][IdSelect];
	ReceiveID1.target=_AddrSel[SourceMotorCtrl][IdSelect];
	ReceiveID2.target=BroadcastAddr;
	
	TravelPara.HorizInc.ParaCmd=PARA_HorizInc;
	TravelPara.HorizInc.paraA=0.1*100;   //0.01MM
	TravelPara.HorizInc.paraB=0;
	TravelPara.HorizSpeed.ParaCmd=PARA_HorizSpeed;
	TravelPara.HorizSpeed.paraA=(float)1000/60;
	TravelPara.HorizSpeed.paraB=0;
	TravelPara.OscFreq.ParaCmd=PARA_OscFreq;
	TravelPara.OscFreq.paraA=((float)1/60);
	TravelPara.OscFreq.paraB=0;
	TravelPara.OscWidth.ParaCmd=PARA_OscWidth;
	TravelPara.OscWidth.paraA=0.1*100;
	TravelPara.OscWidth.paraB=0;
	TravelPara.HoldTime.ParaCmd=PARA_HoldTime;
	TravelPara.HoldTime.paraA=0.001;
	TravelPara.HoldTime.paraB=0;
	TravelPara.TravelSpeed.ParaCmd=PARA_TravelSpeed;
	TravelPara.TravelSpeed.paraA=(float)1000/60;
	TravelPara.TravelSpeed.paraB=0;
	TravelPara.VertiInc.ParaCmd=PARA_VertiInc;
	TravelPara.VertiInc.paraA=0.1*100;
	TravelPara.VertiInc.paraB=0;
	TravelPara.VertiSpeed.ParaCmd=PARA_VertiSpeed;
	TravelPara.VertiSpeed.paraA=(float)1000/60;
	TravelPara.VertiSpeed.paraB=0;
	TravelPara.WidthInc.ParaCmd=PARA_WidthInc;
	TravelPara.WidthInc.paraA=0.1*100;
	TravelPara.WidthInc.paraB=0;
	TravelPara.TravelAdjSpeed.paraA=(float)1000/60;
	TravelPara.TravelAdjSpeed.paraB=0;
}	
u8 CAN_Mode_Init(u8 tsjw,u8 tbs2,u8 tbs1,u16 brp,u8 mode)
{ 
		u16 i=0,j=0;
		if(tsjw==0||tbs2==0||tbs1==0||brp==0)return 1;
		tsjw-=1;//�ȼ�ȥ1.����������
		tbs2-=1;
		tbs1-=1;
		brp-=1;
			

		RCC->APB2ENR|=1<<2;    //ʹ��PORTAʱ��	 
		GPIOA->CRH&=0XFFF00FFF; 
		GPIOA->CRH|=0X000B8000;//PA11 RX,PA12 TX�������   	 
		GPIOA->ODR|=3<<11;
			
		RCC->APB1ENR|=1<<25;//ʹ��CANʱ�� CANʹ�õ���APB1��ʱ��(max:36M)	
				
		CAN->MCR=0x0000;	//�˳�˯��ģʽ(ͬʱ��������λΪ0)
		CAN->MCR|=1<<0;		//����CAN�����ʼ��ģʽ
		while((CAN->MSR&1<<0)==0)
		{
			i++;
			if(i>100)return 2;//�����ʼ��ģʽʧ��
		}
		CAN->MCR|=0<<7;		//��ʱ�䴥��ͨ��ģʽ
		CAN->MCR|=1<<6;		//�����Զ����߹���
		CAN->MCR|=0<<5;		//˯��ģʽͨ����������(���CAN->MCR��SLEEPλ)
		CAN->MCR|=0<<4;		//���������Զ�����
		CAN->MCR|=0<<3;		//���Ĳ�����,�µĸ��Ǿɵ�
		CAN->MCR|=0<<2;		//���ȼ��ɱ��ı�ʶ������
		CAN->BTR=0x00000000;//���ԭ��������.
		CAN->BTR|=mode<<30;	//ģʽ���� 0,��ͨģʽ;1,�ػ�ģʽ;
		CAN->BTR|=tsjw<<24; //����ͬ����Ծ����(Tsjw)Ϊtsjw+1��ʱ�䵥λ
		CAN->BTR|=tbs2<<20; //Tbs2=tbs2+1��ʱ�䵥λ
		CAN->BTR|=tbs1<<16;	//Tbs1=tbs1+1��ʱ�䵥λ
		CAN->BTR|=brp<<0;  	//��Ƶϵ��(Fdiv)Ϊbrp+1
							//������:Fpclk1/((Tbs1+Tbs2+1)*Fdiv)
    CreateID();
		//��������ʼ��
		CAN->FMR|=1<<0;			                                                //�������鹤���ڳ�ʼ��ģʽ
		CAN->FA1R&=~(1<<0);		                                              //������0������
		CAN->FA1R&=~(1<<1);                                                 //������1������
		CAN->FA1R&=~(1<<2);                                                 //������1������
		CAN->FS1R|=7<<0; 		                                                //������0,1,2,3λ��Ϊ32λ.
		CAN->FM1R|=0<<0;		                                                //������0�����ڱ�ʶ������λģʽ
		CAN->FM1R|=0<<1;		                                                //������1�����ڱ�ʶ������λģʽ
		CAN->FM1R|=0<<2;		                                                //������2�����ڱ�ʶ������λģʽ
		CAN->FM1R|=0<<3;		                                                //������3�����ڱ�ʶ������λģʽ
		CAN->FFA1R|=0<<0;		                                                //������0������FIFO0
		CAN->FFA1R|=0<<1;		                                                //������1������FIFO0
		CAN->FFA1R|=0<<2;		                                                //������2������FIFO0
		CAN->FFA1R|=0<<3;		                                                //������3������FIFO0
		CAN->sFilterRegister[0].FR1=*(u16*)&ReceiveID0<<21;                 //32λID
		CAN->sFilterRegister[0].FR2=0XFFC00000;                             //32λMASK	
		CAN->sFilterRegister[1].FR1=*(u16*)&ReceiveID1<<21;                 //32λID
		CAN->sFilterRegister[1].FR2=0X00000000;                             //32λMASK	
		CAN->sFilterRegister[2].FR1=*(u16*)&ReceiveID2<<21;                 //32λID
		CAN->sFilterRegister[2].FR2=0X00000000;                             //32λMASK	                     
			
		CAN->FA1R|=1<<0;		//���������0	
		CAN->FA1R|=1<<1;		//���������1	
//    CAN->FA1R|=1<<2;		//���������2		
		
		CAN->FMR&=~(1<<0);  //���������������ģʽ

		CAN->IER|=1<<1;			//FIFO0��Ϣ�Һ��ж�����.	    
		MY_NVIC_Init(1,1,USB_LP_CAN_RX0_IRQChannel,2);//��2	
		
//		MY_NVIC_Init(1,3,CAN_TX_IRQn,2);
		
		CAN->MCR&=~(1<<0);	//����CAN�˳���ʼ��ģʽ
		while((CAN->MSR&1<<0)==1)
		{
			i++;
			if(i>0XFFF0)return 3;//�˳���ʼ��ģʽʧ��
		}
		while((CAN->ESR&1<<2)==1<<2)  //ȷ���˳�����ģʽ
		{
			j++;
			if(j>0XFFF0) return 1;
		}		
		
		memset(&CANRxInfo,0,sizeof(CANRxInfo));
		memset(&CANTxInfo,0,sizeof(CANTxInfo));
		return 0;
	
}   

u8 Can_Put_Buf(LINK_LIST* LinkList,CanBufTypeDef buffer)
{ 
  if(LinkList->RemainNum<RX_MAX_NUM)
  {
		 if(LinkList==&CANTxLinkList)
        memcpy(&CANTXBUF[LinkList->PutListNum],&buffer,sizeof(CanBufTypeDef));
		 else if(LinkList==&CANRxLinkList)
			  memcpy(&CANRXBUF[LinkList->PutListNum],&buffer,sizeof(CanBufTypeDef));		
		 else return 0;
     LinkList->RemainNum++;
     if(LinkList->PutListNum<TX_MAX_NUM)
       LinkList->PutListNum++;
     else
       LinkList->PutListNum=0;
		 return 1;
  }
}

u8 Can_Get_Buf(LINK_LIST* LinkList,CanBufTypeDef* buffer)
{
  if(LinkList->RemainNum>0)
  {
		if(LinkList==&CANTxLinkList)
		{	
			memcpy(buffer,&CANTXBUF[LinkList->GetListNum],sizeof(CanBufTypeDef));
			if(!Can_Tx_Msg(*buffer))  return 0;
    }
		else if(LinkList==&CANRxLinkList)
		{	
			memcpy(buffer,&CANRXBUF[LinkList->GetListNum],sizeof(CanBufTypeDef));	
			
		}	
		else return 0;
		LinkList->RemainNum--;
		if(LinkList->GetListNum<TX_MAX_NUM)
			LinkList->GetListNum++;
		else
			LinkList->GetListNum=0;  
    return 1; 		
  } return 0;
}

u8 Can_Tx_Msg(CanBufTypeDef buffer)
{	   
	u8 mbox;	  
	if(CAN->TSR&(1<<26))mbox=0;			//����0Ϊ��
	else if(CAN->TSR&(1<<27))mbox=1;	//����1Ϊ��
	else if(CAN->TSR&(1<<28))mbox=2;	//����2Ϊ��
	else return(0);
	CAN->sTxMailBox[mbox].TIR=0;		//���֮ǰ������  
	CAN->sTxMailBox[mbox].TIR|=(((unsigned long)buffer.ID)<<21);		 
	CAN->sTxMailBox[mbox].TIR|=0<<2;	  
	CAN->sTxMailBox[mbox].TIR|=0<<1;
	CAN->sTxMailBox[mbox].TDTR&=~(0X0000000F);
	CAN->sTxMailBox[mbox].TDTR|=buffer.Len;		   //����DLC.
	//���������ݴ�������.
	CAN->sTxMailBox[mbox].TDHR=(((u32)buffer.Databuf[7]<<24)|
								((u32)buffer.Databuf[6]<<16)|
 								((u32)buffer.Databuf[5]<<8)|
								((u32)buffer.Databuf[4]));
	CAN->sTxMailBox[mbox].TDLR=(((u32)buffer.Databuf[3]<<24)|
								((u32)buffer.Databuf[2]<<16)|
 								((u32)buffer.Databuf[1]<<8)|
								((u32)buffer.Databuf[0]));
	CAN->sTxMailBox[mbox].TIR|=1<<0; //��������������
	return 1;
}

void Can_Rx_Msg(u8 fifox,CanBufTypeDef* buffer)
{	    
	u8 i=0; 
	buffer->Len=CAN->sFIFOMailBox[fifox].RDTR&0x0F;//�õ�DLC
	buffer->ID =CAN->sFIFOMailBox[fifox].RIR>>21;  //�õ�ID
	buffer->Databuf[0]=CAN->sFIFOMailBox[fifox].RDLR&0XFF;
	buffer->Databuf[1]=(CAN->sFIFOMailBox[fifox].RDLR>>8)&0XFF;
	buffer->Databuf[2]=(CAN->sFIFOMailBox[fifox].RDLR>>16)&0XFF;
	buffer->Databuf[3]=(CAN->sFIFOMailBox[fifox].RDLR>>24)&0XFF;    
	buffer->Databuf[4]=CAN->sFIFOMailBox[fifox].RDHR&0XFF;
	buffer->Databuf[5]=(CAN->sFIFOMailBox[fifox].RDHR>>8)&0XFF;
	buffer->Databuf[6]=(CAN->sFIFOMailBox[fifox].RDHR>>16)&0XFF;
	buffer->Databuf[7]=(CAN->sFIFOMailBox[fifox].RDHR>>24)&0XFF;    
  	if(fifox==0)CAN->RF0R|=0X20;//�ͷ�FIFO0����
	else if(fifox==1)CAN->RF1R|=0X20;//�ͷ�FIFO1���� 

}

void USB_LP_CAN1_RX0_IRQHandler(void)
{	 
   CanBufTypeDef Rxbuffer;
	 OSIntEnter();
	 Can_Rx_Msg(0,&Rxbuffer);
	 Can_Put_Buf(&CANRxLinkList,Rxbuffer);
	 OSIntExit();
}	

void Can_sendMsg(u16 CID,u8*BYTE,u8 len)
{
	 CanBufTypeDef buffer;
	 buffer.ID=CID;
	 buffer.Len=len;
	 memcpy(buffer.Databuf,BYTE,len);
	 Can_Put_Buf(&CANTxLinkList,buffer);
}

static void SwitchStatusCheck(void)
{
   if(PresentStatus.CycleStatus==StartCycle)
	 {
		 CanTxFlag.CycleCheck=TRUE;
		 StatusCount.CycleCount++;
		 if(StatusCount.CycleCount>=BusOffCount)
		   SwitchStatus.CycleStatus=SwitchOff;	 
	 }	
	 if(PresentStatus.TravelStatus==StartRun)
	 {
		 CanTxFlag.TravelCheck=TRUE;
		 StatusCount.TravelCount++;
		 if(StatusCount.TravelCount>=BusOffCount)
		   SwitchStatus.TravelStatus=SwitchOff;
	 }	
	 if(PresentStatus.WeldingStatus==StartArc)
	 {
		 CanTxFlag.WeldingCheck=TRUE;
		 StatusCount.WeldingCount++;
		 if(StatusCount.WeldingCount>=BusOffCount)
		   SwitchStatus.WeldingStatus=SwitchOff;
	 }	
	 if(PresentStatus.HorizStatus==StartRun)
	 {
		 CanTxFlag.HorizCheck=TRUE;
		 StatusCount.HorizCount++;
		 if(StatusCount.HorizCount>=BusOffCount)
		   SwitchStatus.HorizStatus=SwitchOff;
	 }	
	 if(PresentStatus.VertiStatus==StartRun)
	 {
		 CanTxFlag.VertiCheck=TRUE;
		 StatusCount.VertiCount++;
		 if(StatusCount.VertiCount>=BusOffCount)
		   SwitchStatus.VertiStatus=SwitchOff;
	 }  	 
}	

void StatusCheckTask(void)
{
   SwitchStatusCheck();
	 if(TimeOverFlow.TickFlag1000ms==TRUE)
	 {	 
	   CanTxFlag.HeartBeat=TRUE;
		 TimeOverFlow.TickFlag1000ms=NULL;
	 }	 
}	

u8 CanReceiveProcess(void)
{
   CanBufTypeDef Rxbuffer; u8 NeedAck=NULL,i=0; ECANID_INTERNAL SendID;
	 memset(&CANTxInfo,0,sizeof(CANTxInfo));
	 if(!Can_Get_Buf(&CANRxLinkList,&Rxbuffer)) return 0;
	 memcpy(&CANRxInfo,Rxbuffer.Databuf,Rxbuffer.Len);
	 CANRxInfo.len=Rxbuffer.Len;
	 ReceiveID=*(ECANID_INTERNAL*)&Rxbuffer.ID;
//	 if((Rxbuffer.Databuf[0]==0x9A)||(Rxbuffer.Databuf[0]==0x9C))
	 if((Rxbuffer.Databuf[0]!=0x97)&&(Rxbuffer.Databuf[0]!=0x83)&&(Rxbuffer.Databuf[0]!=0x82)&&(Rxbuffer.Databuf[0]!=0xcb)&&(Rxbuffer.Databuf[0]!=0x04))	 
	 {	 
		u1_printf("%02x>>%02x\r\n",ReceiveID.source,ReceiveID.target);			
		for(i=0;i<Rxbuffer.Len;i++)
		{
			 u1_printf("%02x ",Rxbuffer.Databuf[i]);
		}
		u1_printf("Len=%x\r\n",Rxbuffer.Len);	 
	 }	
}	

u8 CanTransmitProcess(void)
{
	 u16 CANCID;  u8 SendFlag=0,i;
	 if(CanTxFlag.Ack==TRUE)
	 {		  
	    CanTxFlag.Ack=NULL;
		  CANTxInfo.Data[0]=CMD_SendAck;
		  CANTxInfo.len=3;
		  SendFlag=TRUE;
	 } 
	 else if(CanTxFlag.SendParaAck==TRUE)
   {	    
		  CanTxFlag.SendParaAck=NULL;
		  CANTxInfo.Data[0]=CMD_SendParaAck;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  CANTxInfo.len=4;
		  SendFlag=TRUE;
	 }
	 else if(CanTxFlag.TrackSwitch==TRUE)
	 {
		  CanTxFlag.TrackSwitch=NULL;
	    SwingStart.Status=SwitchStatus.AutoTrack;
		  SwingStart.LiftPos=YaxisPos.PdLiftPos;
		  SwingStart.RightPos=YaxisPos.PdRightPos;
		  SwingStart.HightPos=ZaxisPos.RecordPos;
		  memcpy(&CANTxInfo.Data[1],(u8*)&SwingStart,sizeof(SwingStart));
		  CANTxInfo.Data[0]=CMD_AutoTrack;
		  CANTxInfo.len=sizeof(SwingStart)+1;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID1;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  SendFlag=TRUE;
		  
		  u1_printf("TrackSwitch:S %x,L %d,R %d,H %d\r\n",SwingStart.Status,SwingStart.LiftPos,SwingStart.RightPos,SwingStart.HightPos);
	 }
   else if(CanTxFlag.EdgeSign==TRUE)
	 {
	    CanTxFlag.EdgeSign=NULL;
		  CANTxInfo.Data[0]=CMD_EdgeSign;
		  CANTxInfo.Data[1]=EdgeFunc(YaxisPara.Direction);
		  CANTxInfo.len=2;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID1;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  SendFlag=TRUE;
		  
		  u1_printf("EdgeSign: %x\r\n",CANTxInfo.Data[1]);
	 }	
   else if(CanTxFlag.AngleSync==TRUE)
	 {
	    CanTxFlag.AngleSync=NULL;
		  CANTxInfo.Data[0]=CMD_AngleSync;
		  memcpy(&CANTxInfo.Data[1],&DataFeedback.Angle,2);
		  CANTxInfo.len=3;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;  //TransmitID0
		  SendFlag=TRUE;
	 }	
	 else if(CanTxFlag.CycleCheck==TRUE)
   {	    
		  CanTxFlag.CycleCheck=NULL;
		  CANTxInfo.Data[0]=CMD_CycleCheck;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  CANTxInfo.len=1;
		  SendFlag=TRUE;
	 }
	 else if(CanTxFlag.HorizCheck==TRUE)
   {	    
		  CanTxFlag.HorizCheck=NULL;
		  CANTxInfo.Data[0]=CMD_HorizCheck;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  CANTxInfo.len=1;
		  SendFlag=TRUE;
	 }
	 else if(CanTxFlag.TravelCheck==TRUE)
   {	    
		  CanTxFlag.TravelCheck=NULL;
		  CANTxInfo.Data[0]=CMD_TravelCheck;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  CANTxInfo.len=1;
		  SendFlag=TRUE;
	 }
	 else if(CanTxFlag.VertiCheck==TRUE)
   {	    
		  CanTxFlag.VertiCheck=NULL;
		  CANTxInfo.Data[0]=CMD_VertiCheck;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  CANTxInfo.len=1;
		  SendFlag=TRUE;
	 }
	 else if(CanTxFlag.WeldingCheck==TRUE)
   {	    
		  CanTxFlag.WeldingCheck=NULL;
		  CANTxInfo.Data[0]=CMD_WeldingCheck;
		  CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID0;
		  CANTxInfo.len=1;
		  SendFlag=TRUE;
	 }
   else if(CanTxFlag.HeartBeat!=NULL)
   {
	    CanTxFlag.HeartBeat=NULL;
			CANTxInfo.Data[0]= CMD_Heartbeat;	
			CANTxInfo.CID[CANTxInfo.CIdNum++]=*(u16*)&TransmitID2;	
      CANTxInfo.len=3;	
      SendFlag=TRUE;		 
	 }	
   if(SendFlag==TRUE)
	 {		  
		  for(i=0;i<CANTxInfo.CIdNum;i++)
	      Can_sendMsg(CANTxInfo.CID[i],(u8*)&CANTxInfo,CANTxInfo.len); 
      memset(&CANTxInfo,0,sizeof(CANTxInfo));			
		  SendFlag=NULL;
	 }	 
}

void CANTaskOperation(void)
{
   CanReceiveProcess();
}	


