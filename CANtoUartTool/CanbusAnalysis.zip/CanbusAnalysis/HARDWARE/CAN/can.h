#ifndef _CAN_H
#define _CAN_H
#include "lib.h"

#define MaxIdNum              10

#define CMD_GetReady          0x01
#define CMD_WeldingSW         0x02
#define CMD_WFCtrl            0x02
#define CMD_GFCtrl            0x03
#define CMD_WFSpeed           0x04
#define CMD_WeldingCheck      0x05
#define CMD_WeldingSwitch     0x05
#define CMD_TravelCheck       0x06
#define CMD_HorizCheck        0x07
#define CMD_VertiCheck        0x08
#define CMD_WeldingPara       0x0f
#define CMD_PanelLock         0x10
#define CMD_Recall            0x1f
#define CMD_Heartbeat         0x80
#define CMD_SendAck           0x81
#define CMD_PowerOn           0x83
#define CMD_FeedBack          0x97
#define CMD_SettingPara       0x98
#define CMD_SendParaAck       0x99
#define CMD_ErrorAlert        0xa0
#define CMD_AutoTrack         0x9a
#define CMD_OscCtrl           0x9b
#define CMD_HightCtrl         0x9c
#define CMD_EdgeSign          0x9d



#define CMD_CycleSwitch       0x04
#define CMD_LayerSet          0x12
#define CMD_TravelCtrl        0xc2
#define CMD_HorizCtrl         0xc3
#define CMD_VertiCtrl         0xc4
#define CMD_HorizAdj          0xc5
#define CMD_VertiAdj          0xc6
#define CMD_OscSwitch         0xc7
#define CMD_WidthAdj          0xc8
#define CMD_AutoStart         0xc9
#define CMD_TravelAdj         0xca
#define CMD_AngleSync         0xcb
#define CMD_MotorInit         0xcc

#define CMD_CycleCheck        0x04
#define CMD_TravelCheck       0x06
#define CMD_HorizCheck        0x07
#define CMD_VertiCheck        0x08
#define CMD_LayerInfo         0x12
#define CMD_SystemError       0xa0

#define PARA_OscFreq          0xC0
#define PARA_OscWidth         0xC1
#define PARA_TravelSpeed      0xC2
#define PARA_HorizInc         0xC3
#define PARA_VertiInc         0xC4
#define PARA_AutoStartDist    0xC5
#define PARA_HorizSpeed       0xC6
#define PARA_VertiSpeed       0xC7
#define PARA_WidthInc         0xC8
#define PARA_WidthAdj         0xa8
#define PARA_HoldTime         0xCa

#define BusOffCount           5

#define IdSelect              PCin(3)
#define LeadMotor             0
#define TrailMotor            1

typedef struct
{
  u16 ID;
  u8  Len;
  u8  Databuf[8];
}CanBufTypeDef;

typedef struct
{
  u8  PutListNum;
	u8  GetListNum;
	u8  RemainNum;
}LINK_LIST;

typedef struct
{
	 u8 Data[8];
	 u8 len;
	 u16 CID[MaxIdNum];
	 u8  CIdNum;
}CAN_DATA;	

typedef struct
{
   u8 count;
   u8 status;
   u8 workmode;
   u8 error;
   u8 stage;
   u8 speedfeedback;	
}HEARTBEAT_DATA;

typedef struct
{
   u16 WeldingCurrent;
   u16 WeldingVoltage;	
}FEEDBACK_DATA;

typedef __packed struct
{
   u8  ParaCmd;
   u16 ParaData;	
}WELDINGPARA_DATA;


typedef struct
{
   u8 CANTxReady;
	 u8 CANRxReady;
	 u8 CANWaitAck;
	 u8 CANParaInit;
	 u8 SendParaCount;
	 u8 WFRateSend;
	 u8 CANonlineFlag;
	 u8 MemSyncSign;
}STATUS;	

typedef struct
{
	 u8 Material;
	 u8 ModeSwitch;
   u8 WireFeedRate;
	 u8 MigVoltage;	 
}CMD_WELDINGPARA;

typedef struct
{
	 u16* Material;
	 u16* ModeSwitch;
   u16* WireFeedRate;
   u16* MigVoltage;  
}WELDINGPARA_VALUE;	


typedef __packed struct
{
	 u8  Status;
	 u16 LiftPos;
   u16 RightPos;	
	 u16 HightPos;
}SWING_START;

typedef struct
{
	 u8  TrackSwitch;
   u8  WeldingStart;
   u8  EdgeSign;	
	 u8  Ack;
	 u8  MemRecall;
	 u8  SendParaAck;
	 u8  AngleSync;
	 u8  HeartBeat;
	 u8  CycleCheck;
	 u8  WeldingCheck;
	 u8  TravelCheck;
	 u8  HorizCheck;
	 u8  VertiCheck;
}CAN_TX_FLAG;

typedef struct
{
   u8  WeldingCount;
   u8  TravelCount;
   u8  HorizCount;
   u8  VertiCount; 	
	 u8  CycleCount;
}STATUS_COUNT;

extern STATUS              Status;
extern SWING_START         SwingStart;
extern CAN_TX_FLAG         CanTxFlag;

u8 CAN_Mode_Init(u8 tsjw,u8 tbs2,u8 tbs1,u16 brp,u8 mode);
u8 Can_Put_Buf(LINK_LIST* LinkList,CanBufTypeDef buffer);
u8 Can_Get_Buf(LINK_LIST* LinkList,CanBufTypeDef* buffer);
u8 Can_Tx_Msg(CanBufTypeDef buffer);
void Can_Rx_Msg(u8 fifox,CanBufTypeDef* buffer);
void Can_sendMsg(u16 CID,u8*BYTE,u8 len);
u8 CANWatchDogProcess(void);
void CANFeedDog(void);
void CANTaskOperation(void);
u8 CanTransmitProcess(void);
u8 CanReceiveProcess(void);
void StatusCheckTask(void);




#endif