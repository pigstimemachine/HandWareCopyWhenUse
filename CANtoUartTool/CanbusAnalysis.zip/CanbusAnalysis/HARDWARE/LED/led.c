#include "lib.h"

u8 DP1,DP2,DP3,DP4,DP5,DP6; 	
void LED_DP_Init(void)
{
	RCC->APB2ENR|=1<<5;    //ʹ��PORTDʱ��	   	 
	RCC->APB2ENR|=1<<3;	   //
	   	 
	GPIOD->CRL&=0X00000000; 
	GPIOD->CRL|=0X33333333;//PD0~7 ������� 
	GPIOD->ODR|=0XFF;  	 
											  
	GPIOB->CRL&=0XFFF00FFF;
	GPIOB->CRL|=0X00033000;//PB3,4�������
}

void led_Init(void)
{
   
   RCC->APB2ENR|=1<<3;    //ʹ��PORTBʱ��
   RCC->APB2ENR|=1<<2;	  //ʹ��PORTAʱ��
   RCC->APB2ENR|=1<<4;	  //ʹ��PORTCʱ��
   RCC->APB2ENR|=1<<6;	  //ʹ��PORTEʱ��

   GPIOE->CRL&=0X0FFFFFFF; 
   GPIOE->CRL|=0X30000000; //PE7 ���
   GPIOE->ODR|=1<<7;    //PE �������

   GPIOB->CRL&=0X000FFF0F; //PB1,PB5~8���
   GPIOB->CRL|=0X33300030;
   GPIOB->CRH&=0XFFFFFFF0; 
   GPIOB->CRH|=0X00000003;
   GPIOB->ODR|=0X01E2;    //PB1,PB5~8 ������� 

   GPIOA->CRH&=0X0FFFFFFF;//PA15���
   GPIOA->CRH|=0X30000000;
   GPIOA->CRL&=0X0FFFFFFF;//PA7���
   GPIOA->CRL|=0X30000000;
   GPIOA->ODR|=0x8080;	  //PA7,15�������

   GPIOC->CRH&=0XFFF000FF;//PC5��10��11��12���
   GPIOC->CRH|=0X00033300; 
   GPIOC->CRL&=0XFF0FFFFF;
   GPIOC->CRL|=0X00300000;   
   GPIOC->ODR|=0X1C20;	   

}


void led_scan(void)
{
   switch(e)
   {
     case 1:
     { 
	    wela=1;
	    we&=0xFF00;
		we|=0x01;
	    wela=0;
	    dula=1;
		du&=0xFF00;
        du|=DP6;
	    dula=0;
	   break;
	 }	
     case 2:
     {
	    wela=1;
		we&=0xFF00;
	    we|=0x02;
	    wela=0;
	    dula=1;
		du&=0xFF00;
        du|=DP5;
	    dula=0;
	   break;
	 }
	 case 3:
     {
	    wela=1;
		we&=0xFF00;
	    we|=0x04;
	    wela=0;
	    dula=1;
		du&=0xFF00;
        du|=DP4;
	    dula=0;
	   break;
	 }
	 case 4:
     {
	    wela=1;
		we&=0xFF00;
	    we|=0x08;
	    wela=0;
	    dula=1;
		du&=0xFF00;
        du|=DP3;
	    dula=0;
	   break;
	 }	   
	 case 5:
     {
	    wela=1;
		we&=0xFF00;
	    we|=0x10;
	    wela=0;
	    dula=1;
		du&=0xFF00;
        du|=DP2;
	    dula=0;
	   break;		   
	 }
	 case 6:
     {
	    wela=1;
		we&=0xFF00;
	    we|=0x20;
	    wela=0;
	    dula=1;
		du&=0xFF00;
        du|=DP1;
	    dula=0;
	   break;
	 }
   }	
}

  



