#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

extern u8 DP1,DP2,DP3,DP4,DP5,DP6;
#define LED1 PAout(15)
#define LED2 PCout(10)
#define LED3 PCout(11)
#define LED4 PCout(12)
#define LED5 PBout(5)
#define LED6 PBout(6)
#define LED7 PBout(7)
#define LED8 PBout(8)
#define LED9 PAout(7)
#define LED10 PCout(5)
#define LED11 PBout(1)
#define LED12 PEout(7)

	
#define wela PBout(4)
#define dula PBout(3)
#define du GPIOD->ODR
#define we GPIOD->ODR
void LED_DP_Init(void);
void led_scan(void);
void led_Init(void);		 				    
#endif

















