#include "lib.h"

void DipSwitch_Init(void)
{    
	RCC->APB2ENR|=1<<5;     //PORTD
	RCC->APB2ENR|=1<<4;     //PORTC
	
	GPIOD->CRL&=0XFFF00000;	//PD0,1,2,3,4
	GPIOC->CRH&=0XFFF000FF; //PC10,11,12

	GPIOD->CRL|=0X00088888;	
	GPIOC->CRH|=0X00088800;
			   
	GPIOD->ODR|=0x1f<<0;		  
	GPIOC->ODR|=0x07<<2;		  
} 

