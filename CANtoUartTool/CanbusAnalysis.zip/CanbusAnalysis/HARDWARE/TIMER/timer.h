#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"

 typedef struct
{
	 u8  TickFlag1ms;
   u8  TickFlag10ms;
	 u8  TickFlag100ms;
	 u8  TickFlag1000ms;
	 u8  TickFlag2000ms;
	 u32 TickCount;
	 u32 WatchDogCount;
	 u8  CAN2RestFlag;
}TIME_OVERFLOW;	
extern TIME_OVERFLOW TimeOverFlow;	
void TIM3_Int_Init(u16 arr,u16 psc);
void TIM2_Int_Init(u16 arr,u16 psc);
void TIM4_Int_Init(u16 arr,u16 psc);
void TIM6_Int_Init(u16 arr,u16 psc);
void TIM7_Int_Init(u16 arr,u16 psc);
void TIM6_Set(u8 sta);
void Heartbeat_Send(void);
void TIM5_IRQHandler(void);
void TIM5_Int_Init(u16 arr,u16 psc);
void TIM5_Set(u8 sta);
void TimerInit(void);
unsigned char TimerIsOverflowEvent(void);
void TimeCount(void);
#endif























