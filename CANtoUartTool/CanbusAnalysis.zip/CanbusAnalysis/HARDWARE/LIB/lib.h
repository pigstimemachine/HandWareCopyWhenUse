#ifndef __LIB_H
#define __LIB_H	

#include <string.h>
#include <math.h>
#include "stdlib.h"
#include "sys.h"
#include "delay.h"
#include "usart.h"			
//#include "led.h" 	 	  	 
//#include "exti.h"
#include "timer.h"
#include "can.h"
#include "stdarg.h"	 	 
#include "stdio.h"
#include "stm32f10x_conf.h"
#include "Motor.h"
#include "IIC.h"
#include "FRAM.h" 
#include "adxl345.h"
#include "includes.h"

extern OS_EVENT * sem_IIC;
extern OS_EVENT * msg_OscAdj;
extern OS_EVENT * msg_Origin;
extern OS_EVENT * msg_HightAdj;

typedef struct tagECANID_INTERNAL
{
	unsigned short reserved:3;	//0b000
	unsigned short source:4;	//Source address
	unsigned short target:4;	//Target address
}ECANID_INTERNAL;


#define DeviceNetSupport      0     //0:��֧��DeviceNet  1��֧��DeviceNet  
#define YES                   1
#define NO                    0			
#define OFF				            0
#define ON                    1
#define LEDON                 0
#define LEDOFF  		          1
#define Disable               0
#define Enable                1
#define RX_MAX_NUM            100
#define TX_MAX_NUM            100
#define SendAck               1
#define SendPara              2
#define CanTimeOutNum        5000  //5s


	
#define LeadMotorCtrlAddr        0x12
#define TrailMotorCtrlAddr       0x13
#define RemoteCtrlAddr           0x11
#define MainCtrlAddr             0x10
#define LeadDPS500Addr           0x08
#define TrailDPS500Addr          0x09
#define BroadcastAddr            0x1f			

	
#define WFswitchOn            0x5a
#define WFswitchOff           0xa5
#define WFstatusOn            0x55
#define WFstatusOff           0x4a
#define WFswitch(x)           (x==0?WFswitchOff:WFswitchOn)
#define WFstatus(x)           (x==0?WFstatusOff:WFstatusOn)  


#define NUM_Material          0
#define NUM_ModeSwitch        1
#define NUM_WireFeedRate      2
#define NUM_MigVoltage        3

#define PowerOnInit           0
#define ParaSyncInit          1
#define CompleteInit          2
#define SendToDPS             0
#define SendToWfeeder         1
#define MODEL_DPS500          0x50
#define SampleMaterial        6
#define SampleModeSwitch      1

			
#define GetMacID              (unsigned char)PCin(12)|(PDin(0)<<1)|(PDin(1)<<2)|(PDin(2)<<3)|(PDin(3)<<4)|(PDin(4)<<5)
#define GetBaudRate           (unsigned char)PCin(10)|(PCin(11))

#define TimeoutTick          10000000
#define MaxHoldTime          100000  
//////////////////////////////////////////////FRAM
#define ADDR_XaxisPos         0
#define LEN_XaxisPos          4
#define ADDR_YaxisPos         4
#define LEN_YaxisPos          4
#define ADDR_ZaxisPos         8
#define LEN_ZaxisPos          4


//////////////////////////////////////////////UART

typedef struct
{
	u32 XaxisPos;
	u32 YaxisPos;
	u32 ZaxisPos;
	u16 Angle;
}DATA_FEEDBACK;

typedef struct
{
	u8  Item;
	u8  WeldingStart:4;
	u8  AutoMma:4;
	u8  XRstart:4;
	u8  XLstart:4;
	u8  YRstart:4;
	u8  YLstart:4;
	u8  ZRstart:4;
	u8  ZLstart:4;
	u8  TrackSwitch:4;
}SWITCH;

typedef struct
{
	u8  HeadByte;
	u8  DataLen;
  u8* Data;
  u8  EndByte;	
}UART_FORMAT;

typedef struct
{
	u8  UartTxFlag;
	u8  UartRxFlag;
}UART_PARA;

extern SWITCH       TrackSwitch;
extern UART_FORMAT  UartTxFormat;
extern UART_PARA    UartPara;
extern DATA_FEEDBACK DataFeedback;

#define ItemFreq        0
#define ItemWidth       1
#define ItemHoldTime   2
#define ItemXaxisspeed  3
#define ItemYaxisspeed  4
#define ItemZaxisspeed  5
#define ItemAxisInit    6

#define SwYLstart        1
#define SwXRstart        2
#define SwYRstart        3
#define SwXLstart        4
#define SwAutoMma        5
#define SwWeldingStart   6

#define XLstartFlag          1
#define XRstartFlag          2
#define YLstartFlag          1
#define YRstartFlag          2
#define ZLstartFlag          1
#define ZRstartFlag          2
#define StopFlag             0

#define ItemPara             0x01
#define ItemSwitch           0x02
#define ItemFeedback         0x01

#define SelAuto              1
#define SelMma               0

#define Operation            1
#define Suspend              0

#define ERROR_YaxisAcc       1
#define ERROR_YaxisPos       2
/////////////////////////////////////Angle
#define Degree_A             30
#define Degree_B             120
#define Degree_C             150
#define Degree_D             180
#define Hysteresis           10  
#define First                1
#define Second               2
#define Third                3
#define Fourth               4



#endif
