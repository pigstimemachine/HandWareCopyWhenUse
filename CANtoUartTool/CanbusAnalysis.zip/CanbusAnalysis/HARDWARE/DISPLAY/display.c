#include "sys.h" 
#include"Can_Receive.h" 
#include "CodeSwitch.h"
#include"display.h"
#include"can.h"
#include"delay.h"
#include"led.h" 
#include "key.h"
#include "lib.h"

u8 table[]=
{
  0xC0,0XF9,0xA4,0xB0,0x99,
  0x92,0x82,0xF8,0x80,0x90,
} ;

#define ABS(x) ((x)>0?(x):-(x))

void display(void)
{     
  LightOff();
  if(mode!=mode_MMA)
  {
	  STEP_DP();
	  First_Item_Renew();
	  Second_Item_Renew();
	  TEST_DP();
	  switch(MENU)
	  {
	     case loading:
		 {
		    Loading_DP();			 //�������ؽ���
			if(mode!=NO)
			  MENU=first;
			break;
		 }
	     case first:				 //���˵���ʾ
		 {
			FirstMenu_DP();
		    break;
		 }
		 case second:				 //�����˵���ʾ
		 {
			SecondMenu_DP();
		    break;
		 }
		 case program:				 //���������ʾ
		 {
			ProgramMenu_DP();
		    break;
		 }
		 case va_data:				 //������ѹ������ʾ
		 {
			VA_dataMenu_DP();
		    break;
		 }
		 case error:
		 {
			Error_DP();
		    break;
		 }
	  }
	  if(error==1)
	  {
	     DP1=0X86;
	     DP2=0XFF;
	     DP3=0XFF;
	     DP4=table[F_alert%10];			  
	     DP5=table[F_alert%100/10];
	     DP6=table[F_alert/100];
	  }
  }
  else
  {
      DP1=DP2=DP3=DP4=DP5=DP6=0XBF;
  }
}

void Loading_DP(void)
{	
    DP3=0x89; //H 
	DP2=0x86; //E
    DP1=0xc7; //L   
	DP6=0Xc7; //L
	DP5=0Xc0; //O
	DP4=0xff;
}
void FirstMenu_DP(void)			   //��������ʾ
{
    LED1=LEDON;
	W_speedIPM=((W_speed*100+64)/127)*5;
    DP1=table[W_speedIPM%10];
    DP2=table[W_speedIPM%100/10];
    DP3=table[W_speedIPM/100];
	switch(First_Item)
	{
	   case Item_volt:
	   {
	      LED5=LEDON;
	      if(mode==mode_CV)		       // ��ѹ
           {		     
		     DP4=table[volt%10];
	         DP5=table[volt%100/10]&0X7F;
	         DP6=table[volt/100];
		   }
		  if(mode==mode_short)
		   {
		     DP4=table[ABS((S_volt-20)%10)];
	         DP5=table[ABS((S_volt-20)%100/10)];
			 if((S_volt-20)>=0)					//����
	           DP6=0xFF;
			 else
			   DP6=0xBF;
		   }
	      break;
	   }
	   case Item_arc_length:
	   {
	      LED6=LEDON;
	      if(mode==mode_pluse|mode==mode_CC)		//����
		   {
		     DP4=table[ABS(arc_length-20)%10];
	         DP5=table[ABS(arc_length-20)%100/10];
	         if((arc_length-20)>=0)				  //����
	            DP6=0xFF;
		     else
		        DP6=0xBF;
		   }
		  if(mode==mode_short)				       //p2	����
		   {
		      DP4=table[ABS(S_freq-20)%10];
	          DP5=table[ABS(S_freq-20)%100/10];			   	
	          if((S_freq-20)>=0)				   //����
	             DP6=0xFF;
		      else
		         DP6=0xBF;
		   }
	      break;
	   }
	   case Item_deflection:			 //ͦ��
	   {
	      LED7=LEDON;
	      if(mode!=mode_CV)			    
		   {
			  DP4=table[ABS((deflection-20)%10)];
		      DP5=table[ABS((deflection-20)%100/10)];
		      if((deflection-20)>=0)					//����
		         DP6=0xFF;
			  else
			     DP6=0xBF;
		   }
		  else						    //���
		   {
			  DP4=table[ABS(indu-20)%10];	 
			  DP5=table[ABS(indu-20)%100/10]; 		    
			  if((indu-20)>=0)
			     DP6=0xFF;  
		      else
				 DP6=0xBF;					 //����
		   }
	      break;
	   }
	   case Item_frequency:					 //Ƶ��
	   {
	      LED8=LEDON;
	      if(mode==mode_pluse)				 //p1
		   {
			  DP4=table[ABS(frequency-20)%10];
	          DP5=table[ABS(frequency-20)%100/10]; 			   	
	          if((frequency-20)>=0)
	             DP6=0xFF;  
		      else
		         DP6=0xBF;						   //����
		   }
	      break;
	   }
	}
}

void SecondMenu_DP(void)					 //�����˵���ʾ
{
   DP1=table[Second_Item%10];
   DP2=table[Second_Item%100/10];
   DP3=0x46;
   switch(Second_Item)
   {
     case 1:								  //˿��
	  {	
	    W_speedIPM=((W_speed*100+64)/127)*5;
	    DP4=table[W_speedIPM%10];
	    DP5=table[W_speedIPM%100/10];
	    DP6=table[W_speedIPM/100];
		break;
	  }
     case 3:								  //CV��ѹ
	  {	
	    DP4=table[volt%10];
        DP5=table[volt%100/10]&0X7F;
        DP6=table[volt/100];
		break;
	  }
	 case 5:								  //CV���
	  {	
	    DP4=table[ABS(indu-20)%10];	 
	    DP5=table[ABS(indu-20)%100/10]; 		    
	    if((indu-20)>=0)
	       DP6=0xFF;  
		else
		   DP6=0xBF;					 //
		break;
	  }			 
	 case 10:								  //����
	  {	
	    DP4=table[ABS(arc_length-20)%10];
        DP5=table[ABS(arc_length-20)%100/10];
        if((arc_length-20)>=0)				  //����
           DP6=0xFF;
        else
           DP6=0xBF;					 //
		break;
	  }
	 case 11:								  //Ƶ��
	  {	
	    DP4=table[ABS(frequency-20)%10];
        DP5=table[ABS(frequency-20)%100/10]; 			   	
        if((frequency-20)>=0)
           DP6=0xFF;  
	    else
	       DP6=0xBF;						   //����
		break;
	  }
	 case 12:								  //ͦ��
	  {	
	    DP4=table[ABS((deflection-20)%10)];
	    DP5=table[ABS((deflection-20)%100/10)];
	    if((deflection-20)>=0)					//����
	       DP6=0xFF;
		else
		   DP6=0xBF;
		break;
	  }
	 case 15:									//MIG pulse current
	  {	
	    DP4=table[ABS(Pulse_current-100)%10];	     
	    DP5=table[ABS(Pulse_current-100)%100/10];												  
	    if((Pulse_current-100)>=0)
	       DP6=0xFF;
		else
		   DP6=0xBF;	             //����
		break;
	  }			 
	 case 16:								  //��ֵ
	  {	
	    DP4=table[ABS(mid_current-100)%10];	     
	    DP5=table[ABS(mid_current-100)%100/10]; 		    
	    if((mid_current-100)>=0)
	       DP6=0xFF; 
		else
		   DP6=0xBF;	             //����					 
		break;
	  }
	 case 17:									//MIG base current
	  {	
	    DP4=table[ABS(B_current-100)%10];	     
	    DP5=table[ABS(B_current-100)%100/10]; 		  	
	    if((B_current-100)>=0)
	       DP6=0xFF; 
		else
		   DP6=0xBF;	             //����
		break;
	  }
	 case 20:								  //P2��ѹ
	  {	
	    DP4=table[ABS((S_volt-20)%10)];
        DP5=table[ABS((S_volt-20)%100/10)];
		if((S_volt-20)>=0)			  //����
          DP6=0xFF;
		else
		  DP6=0xBF;
		break;
	  }
	 case 21:								  //p2����
	  {	
	    DP4=table[ABS(S_freq-20)%10];
        DP5=table[ABS(S_freq-20)%100/10];			   	
        if((S_freq-20)>=0)			 //����
           DP6=0xFF;
	    else
	       DP6=0xBF;
		break;
	  }
	 case 22:								  //P2�绡����
	  {	
	    DP4=table[ABS(arc_control-20)%10];	 
	    DP5=table[ABS(arc_control-20)%100/10]; 		    
	    if((arc_control-20)>=0)
	       DP6=0xFF;  
		else
		   DP6=0xBF;					 //
		break;
	  }
	 case 23:								  //p2 cvgain(���ɿ���)
	  {	
	    DP4=table[ABS(cvgain-20)%10];	 
	    DP5=table[ABS(cvgain-20)%100/10]; 		    
	    if((cvgain-20)>=0)
	       DP6=0xFF;  
		else
		   DP6=0xBF;					 //
		break;
	  }
	 case 26:								  //p2 ��ֵ����
	  {	
	    DP4=table[ABS(SP_current-100)%10];	     
	    DP5=table[ABS(SP_current-100)%100/10]; 		    
	    if((SP_current-100)>=0)
	       DP6=0xFF;
		else
		   DP6=0xBF;	             //����
	    break;
	  }
	 case 27:								  //p2 ��ֵ����
	  {	
	    DP4=table[ABS(SB_current-100)%10];	     
	    DP5=table[ABS(SB_current-100)%100/10]; 		    
	    if((SB_current-100)>=0)
	       DP6=0xFF; 
		else
		   DP6=0xBF;	             //����
		break;
	  }
	
	 case 40:
	  {
	    SW_speedIPM=((SW_speed*100+64)/127)*5;
	    DP4=table[SW_speedIPM%10];			  //����˿�ٶ�
	    DP5=table[SW_speedIPM%100/10];
	    DP6=table[SW_speedIPM/100];
		break;
	  }
	 case 41:								  //MIG ����΢��
	  {	
	    DP4=table[ABS(arc_adj-20)%10];	 
	    DP5=table[ABS(arc_adj-20)%100/10]; 		    
	    if((arc_adj-20)>=0)
	       DP6=0xFF;  
		else
		   DP6=0xBF;					 //����
		break;
	  }
     case 42:
	  {
	    DP4=table[T_before%10];			  //ǰ��
	    DP5=table[T_before%100/10]&0x7f;
	    DP6=table[T_before/100];
		break;
	  }
	 case 43:
	  {
	    DP4=table[T_after%10];			  //����
	    DP5=table[T_after%100/10]&0x7f;
	    DP6=table[T_after/100];
		break;
	  }			
	 case 45:							//���ճ̶�	   
	  {	
	    DP4=table[ABS(strength-20)%10];	 
	    DP5=table[ABS(strength-20)%100/10]; 		    
	    if((strength-20)>=0)
	       DP6=0xFF;				   
		else
		   DP6=0xBF;					 //����
		break;
	  }
	 case 50:								 //MIG ��ʼʱ��
	  {
	    DP4=table[start_t%10];			  
	    DP5=table[start_t%100/10]&0x7f;
	    DP6=table[start_t/100];
		break;
	  }
	 case 51:								 //MIG ��ʼ˿��
	  {
	    DP4=table[(start_wfs*5)%10];
	    DP5=table[(start_wfs*5)%100/10];
	    DP6=table[(start_wfs*5)/100];
		break;
	  }
	 case 52:								 //MIG �ջ�ʱ��
	  {
	    DP4=table[stop_t%10];			  
	    DP5=table[stop_t%100/10]&0x7f;
	    DP6=table[stop_t/100];
		break;
	  }			 
	 case 53:								 //MIG �ջ�˿��
	  {
	    DP4=table[(stop_wfs*5)%10];
	    DP5=table[(stop_wfs*5)%100/10];
	    DP6=table[(stop_wfs*5)/100];
		break;
	  }
	 case 60:								   //MIG dual pulse freq
	  {	
	    DP4=table[dual_freq%10];	 
	    DP5=table[dual_freq%100/10];		    
	    DP6=0xff;
		break;
	  }
	 case 80:
	  {
	    DP4=table[tack_time%10];			  //�㺸ʱ��
	    DP5=table[tack_time%100/10]&0x7f;
	    DP6=table[tack_time/100];
		break;
	  }	
   }
}

void ProgramMenu_DP(void)
{
   LED10=LEDON;
   DP1=0X8E;
   DP2=0XFF;
   DP3=0XFF;
   DP4=table[R_prog%10];			  
   DP5=table[R_prog%100/10];
   DP6=table[R_prog/100];
}

void Error_DP(void)
{
   DP1=0X86;
   DP2=0XFF;
   DP3=0XFF;
   DP4=table[F_alert%10];			  
   DP5=table[F_alert%100/10];
   DP6=table[F_alert/100];
}

void VA_dataMenu_DP(void)
{
   DP1=table[C%10];
   DP2=table[C%100/10];
   DP3=table[C/100];
   DP4=table[V%10];
   DP5=table[V%100/10]&0X7F;
   DP6=table[V/100];
}

void STEP_DP(void)
{
   if(step==four_step)
      LED9=LEDON;
}
void LightOff(void)
{
   GPIOE->ODR|=1<<7;    //PE �������
   GPIOB->ODR|=0X01E2;    //PB1,PB5~8 �������
   GPIOA->ODR|=0x8080;	  //PA7,15�������
   GPIOC->ODR|=0X1C20;
}

void First_Item_Renew(void)
{
   switch(mode)
   {
     case mode_pluse:				 //����
     {
       First_Item=PLUSE1[FirstItem_pluse];		 //����
       break;
     }
     case mode_CV:				     //CV
     {
       First_Item=CV1[FirstItem_CV];			//��ѹ
       break;
     }
     case mode_CC:				     //CC
     {
       First_Item=CC1[FirstItem_CC];			//����
       break;
     }
     case mode_short:				 //P2
     {
       First_Item=SHORT1[FirstItem_short];		//����
       break;
     }
   }
}

void Second_Item_Renew(void)
{
   switch(mode)
   {
     case mode_pluse:				 //����
     {
       Second_Item=PLUSE2[SecondItem_pluse];
       break;
     }
     case mode_CV:				     //CV
     {
       Second_Item=CV2[SecondItem_CV];
       break;
     }
     case mode_CC:				     //CC
     {
       Second_Item=CC2[SecondItem_CC];
       break;
     }
     case mode_short:				 //p2
     {
       Second_Item=SHORT2[SecondItem_short];
       break;
     }
   }
}
void TEST_DP(void)
{
   if(Gas_feed==YES)
   {
      LED11=LEDON;
   }
   if(Wire_feed==YES)
   {
      LED12=LEDON;
   }
}
