#ifndef __DISPLAY_H
#define __DISPLAY_H
#include "sys.h"
void display(void);
void FirstMenu_DP(void);
void SecondMenu_DP(void);
void ProgramMenu_DP(void);
void Error_DP(void);
void VA_dataMenu_DP(void);
void LightOff(void);
void STEP_DP(void);
void Second_Item_Renew(void);
void First_Item_Renew(void);
void TEST_DP(void);
void Loading_DP(void);
#endif
