#ifndef __SWITCH_H
#define __SWITCH_H	 
#include "sys.h"
void Switch(void);
#endif

