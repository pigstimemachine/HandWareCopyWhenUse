#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"
	 
#define key1 PCin(4)  
#define key2 PBin(0)
#define key3 PBin(2)  
#define key4 PEin(8)

extern u8 Menu,Check_Gas,Gas_feed,Wire_feed;  
void KEY_SCAN(void);
void KEY_Init(void);//IO��ʼ��	
void KEY1_SACN(void);
void KEY2_SACN(void);
void KEY3_SACN(void);
void KEY4_SACN(void);
void LButtom_SACN(void);
void RButtom_SACN(void);
u8 StepSwitch(u8 Step);				    
#endif
