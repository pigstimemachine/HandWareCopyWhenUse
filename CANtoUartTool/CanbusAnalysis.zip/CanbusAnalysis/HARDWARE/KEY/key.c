#include "key.h"
#include "sys.h"
#include "delay.h"
#include"timer.h"
#include"led.h"
#include "CodeSwitch.h"
#include"Can_Receive.h"
#include "can.h"
#include "lib.h"
u8 Key,KEY,Check_Gas=0,SW_STEP=0,Menu=0,LBON=0,RBON=0,K1ON=0,K2ON=0,K3ON=0,K4ON=0,Gas_feed,Wire_feed;
#define SWITCH(x) ((x)==1?(0x5A):(0xA5))
#define MENU_SWITCH(x) ((x)==1?(second):(first))
void KEY_Init(void)
{    
	RCC->APB2ENR|=1<<3;     //ʹ��PORTBʱ��
	RCC->APB2ENR|=1<<6;     //ʹ��PORTEʱ��
	RCC->APB2ENR|=1<<4;     //ʹ��PORTCʱ��
	
	RCC->APB2ENR|=1<<0;	   //ʹ��AFIO  ʱ��
	AFIO->MAPR|=1<<25;     //  �رո���
	GPIOB->CRL&=0XFFFFF0F0;	//PB0,2���ó�����
	GPIOC->CRL&=0XFFF0FFFF;	//PC4���ó�����
	GPIOE->CRH&=0XFFFFFFF0; //PE8����Ϊ���� 

	GPIOB->CRL|=0X00000808;
	GPIOC->CRL|=0X00080000;	
	GPIOE->CRH|=0X00000008;
			   
	GPIOB->ODR|=5<<0;	   	//PB0,2 ����
	GPIOE->ODR|=1<<8;		//PE8  ����
	GPIOC->ODR|=1<<4;		//PC4 ����
} 

void KEY_SCAN(void)
{
   if(KEY<6) KEY++;	       
   else KEY=0;
   switch(KEY)
   {
	  case KEY1:
	  {
		 KEY1_SACN(); 
	     break;
	  }
	  case KEY2:
	  {
		 KEY2_SACN();
	     break;
	  }
	  case KEY3:
	  {
		 KEY3_SACN();
	     break;
	  }
	  case KEY4:
	  {
		 KEY4_SACN();
	     break;
	  }
	  case LBottom:
	  {
		 LButtom_SACN();
	     break;
	  }
	  case RBottom:
	  {
		 RButtom_SACN();
	     break;
	  }
   }
   if(Key==ON)
   {		   		     	   	
	 Time=0;setting=YES;
	 TIM7_Int_Init(10000,7200);
   }	
}


void KEY4_SACN(void)
{ 
   	if(key4==IN)
    {
       NUM.K4++;
	   if((NUM.K4>=NUM_MIN)&&(K4ON==NO))
	   {
	      BYTE[0]=0X04;
		  BYTE[1]=(W_speed)&0XFF;
		  BYTE[2]=(W_speed)>>8;
		  send_Msg2(BYTE,3);
	      BYTE[0]=0X02;
	      BYTE[1]=0X5A;			//������˿	 
		  send_Msg2(BYTE,2); 
	      Key=ON;K4ON=YES; Wire_feed=YES;
	   }			 
    }
    else
    {
       if(NUM.K4<NUM_MIN)
	   {
	      Key=OFF;		  
	   }
	   else
	   {
	      BYTE[0]=0X02;
	      BYTE[1]=0XA5;			//ֹͣ��˿
		  send_Msg2(BYTE,2);
		  Wire_feed=NO;	  
	   }
       NUM.K4=0; K4ON=NO;
    }
}

void KEY3_SACN(void)
{
    BYTE[0]=0X03;
   	if(key3==IN)
    {
       NUM.K3++;
	   if((NUM.K3>=NUM_MAX)&&(K3ON==NO))
	   {
	      Key=ON,K3ON=YES;

	   }			 
    }
    else
    {
       if(NUM.K3<NUM_MIN)
	   {
	      Key=OFF;
	   }
       else if((NUM.K3>=NUM_MIN)&&(NUM.K3<NUM_MAX))
	   {
	 	  Key=ON;  
		  Check_Gas=!Check_Gas;
		  Gas_feed=Check_Gas;
		  BYTE[1]=SWITCH(Check_Gas);
		  send_Msg2(BYTE,2);
		  TIM5_Set(ON);
	   }	   
       NUM.K3=0; K3ON=NO;
    }
}

void KEY2_SACN(void)
{
   	if(key2==IN)
    {
       NUM.K2++;
	   if((NUM.K2>=NUM_MAX)&&(K2ON==NO)&&(MENU==program))
	   {
	      Key=ON; K2ON=YES;			  	  
	   }			 
    }
    else
    {
       if(NUM.K2<NUM_MIN)
	   {
	      Key=OFF;
	   }
       else if((NUM.K2>=NUM_MIN)&&(NUM.K2<NUM_MAX))
	   {
	 	  Key=ON;
		  if(MENU==program)
		  {		     
			 MENU=first;
		  }
		  else
		  {
		     MENU=program;
		  }
	   }
       NUM.K2=0; K2ON=NO;
    }
}

void KEY1_SACN(void)
{
    BYTE[0]=0X8f;
	BYTE[1]=0X63;
   	if(key1==IN)
    {
       NUM.K1++;
	   if((NUM.K1>=NUM_MAX)&&(K1ON==NO))
	   {
	      Key=ON,K1ON=YES;
	   }				 
    }
    else
    {
       if(NUM.K1<NUM_MIN)
	   {
	      Key=OFF;
	   }
       else if((NUM.K1>=NUM_MIN)&&(NUM.K1<NUM_MAX))
	   {
	 	  Key=ON;
		  step=StepSwitch(step);
		  BYTE[2]=SWITCH(step);
		  send_Msg1(BYTE,3);
	   }
       NUM.K1=0;K1ON=NO;
    }
}



void LButtom_SACN(void)
{
   	if(Lbottom==IN)
    {
       NUM.LB++;	   
	   if((NUM.LB>=NUM_MAX)&&(LBON==NO))						//����
	   {
	      Key=ON; LBON=YES;
		  #if MenuDefine
		  MENU=second;
		  #endif
	   }			 
    }
    else
    {
       if(NUM.LB<NUM_MIN)
	   {
	      Key=OFF;
	   }
       else if((NUM.LB>=NUM_MIN)&&(NUM.LB<NUM_MAX))	//�̰�
	   {
	 	  Key=ON;
		  if(MENU!=first)
		     MENU=first;        //��������
		  else if(status==weldding)
		     MENU=va_data;
	   }
       NUM.LB=0;LBON=NO;
    }
}

void RButtom_SACN(void)
{
   	if(Rbottom==IN)
    {
       NUM.RB++;
	   if((NUM.RB>=NUM_MAX)&&(RBON==NO))						//����
	   {
	      Key=ON; RBON=YES;
	   }			 
    }
    else
    {
       if(NUM.RB<NUM_MIN)
	   {
	      Key=OFF;
	   }
       else if((NUM.RB>=NUM_MIN)&&(NUM.RB<NUM_MAX))	  //�̰�
	   {
	 	  Key=ON;
		  if(MENU==first)
		  {
			  switch(mode)
			  {
			    case mode_pluse:			  //����
			    {
					FirstItem_pluse=0;
				    break;
				}
				case mode_CV:				//CV
			    {
				    if(FirstItem_CV<1)
					   FirstItem_CV++;
					else
					   FirstItem_CV=0;
				    break;
				}
				case mode_CC:				//CC
			    {
				    FirstItem_CC=0;
				    break;
				}
				case mode_short:			//p2
			    {
					FirstItem_short=0;
					break;
				}
			 }	
		  }
		  else if(MENU==program)
		  {
		     BYTE[0]=0X93;
             BYTE[1]=(R_prog-1)&0XFF;
             send_Msg1(BYTE,2);	
			 MENU=first;
		  }
	   }
       NUM.RB=0; RBON=NO;
    }
}

u8 StepSwitch(u8 Step)
{
   if(Step!=double_step)
     Step=double_step;
   else if(Step!=four_step)
     Step=four_step;
   return Step;
}




