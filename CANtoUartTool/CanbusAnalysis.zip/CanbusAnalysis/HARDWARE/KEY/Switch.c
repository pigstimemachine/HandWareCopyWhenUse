#include "key.h"
#include "sys.h"
#include "delay.h"
#include"timer.h"
#include"led.h"
#include "CodeSwitch.h"
#include "Switch.h"
#include "can.h"
extern u8 num15,num16,num17,num18,r_feeder1,r_feeder2,change; 
void Switch(void)
 {
   switch(key23)
    {
	  case 0:
	   {
	     num16=0;
	     if(r_feeder1==0)	  
	       num15++;
	     if(num15>10)
		   {
		      num15=0;
		      r_feeder1=1;
			  change=1;
		   }
		 break;
	   }
	  case 1:
	   {
	      num15=0;
	      if(r_feeder1==1)
		    num16++;
		  if(num16>10)
		   {
		      num16=0;
		      r_feeder1=0;
			  change=1;
		   }
		 break;
	   }
	}
   switch(key24)
    {
	  case 0:
	   {
	     num18=0;
	     if(r_feeder2==0)	  
	       num17++;
	     if(num17>5)
		   {
		      num17=0;
		      r_feeder2=1;
			  change=1;
		   }
		 break;
	   }
	  case 1:
	   {
	      num17=0;
	      if(r_feeder2==1)
		    num18++;
		  if(num18>5)
		   {
		      num18=0;
		      r_feeder2=0;
			  change=1;
		   }
		 break;
	   }
	}
 }
