#include "sys.h"
#include "usart.h"		
#include "delay.h"	
#include "led.h" 	 	 
#include "key.h"	 	 
#include "exti.h"
#include "timer.h"
extern u8 TH;
extern u8 TH1;
extern u8 TH2;
extern u8 TM;
extern u8 TM1;
extern u8 TM2;
extern u8 TS;
extern u8 TS1;
extern u8 TS2;
extern u8 CH;
extern int temp;
extern u8 a,b,c,d;
extern u8 oldBMB;
void surface(void)
{
  switch(CH)
  {
	case 1:
	{
	  if(oldBMB==0)
		 {
		    LED3=!LED3;
			if(TS<59)
		    TS++;
			else 
			TS=0;	
	      }
	  if(oldBMB==1)
		  {
		    LED4=!LED4;
			if(TS>0)
		    TS--;
			else
			TS=59;
	      }
	  break;
	}
	case 2:
	{
	  if(oldBMB==0)
		 {
		    LED3=!LED3;
			if(TM<59)
		    TM++;
			else
			TM=0;	
	      }
	  if(oldBMB==1)
		  {
		    LED4=!LED4;
			if(TM>0)
		    TM--;
			else
			TM=59;
		  }
	  break;
	}
	case 3:
	{
	  if(oldBMB==0)
		 {
		    LED3=!LED3;
			if(TH<23)
		    TH++;
			else
			TH=0;	
	      }
	  if(oldBMB==1)
		  {
		    LED4=!LED4;
			if(TH>0)
		    TH--;
			else
			TH=23;
	      }
	  break;
    }
  }
}
