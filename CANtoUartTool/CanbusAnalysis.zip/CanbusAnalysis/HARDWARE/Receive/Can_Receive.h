#ifndef __CAN_RECEIVE_H
#define __CAN_RECEIVE_H	 
#include "sys.h"

extern u8 arc_length,deflection,frequency,S_freq,K_volt,P_current,step,T_before,T_after,W_speed,SW_speed,strength,tack_time,Pulse_current,indu,mid_current,arc_control,cvgain;
extern u8 B_current,dual_freq,arc_adj,SB_current,SP_current,start_t,stop_t,start_wfs,stop_wfs,Arc_Current,Arc_Time,R_prog,W_prog,F_alert,Speed_R;
extern u16 volt,current,V,C,W_speedIPM,SW_speedIPM;
extern int S_volt; 
extern u8 MAT,AL,lock,welding,status;

void Receive(void);
#endif
