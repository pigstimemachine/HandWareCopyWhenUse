#include "sys.h" 
#include"Can_Receive.h"
#include "CodeSwitch.h" 
#include"can.h"
#include"led.h" 
#include "usart.h"
#include "lib.h"
#include "key.h"
u8 arc_length,deflection,frequency,S_freq,K_volt,P_current,step,T_before,T_after,W_speed,SW_speed,strength,tack_time,Pulse_current,indu,mid_current,arc_control,cvgain;
u8 B_current,dual_freq,arc_adj,SB_current,SP_current,start_t,stop_t,start_wfs,stop_wfs,Arc_Current,Arc_Time,W_prog,F_alert,Speed_R,MAT;
u8 R_prog=1,status=0;
u16 volt,current,V,C,W_speedIPM,SW_speedIPM;
int S_volt; 
void Receive(void)
{
  if(rxbuf[0]==0x0F)
   {   
     BYTE[2]=rxbuf[1];
	 BYTE[1]=rxbuf[0];			
	 BYTE[0]=0X81;
	 send_Msg1(BYTE,3);
   } 
//  USART1->CR1|=1<<7;  //���ͻ��������ж�ʹ��
  if((rxbuf[0]==0x0f)|(rxbuf[0]==0x8f))
   {
     switch(rxbuf[1])
      {     
	    case 0x51:			 //MIG dual pulse
	    {

		   break;
	    }
	    case 0x53:			  //MIG ��˿�ٶ�
	    {

		   W_speed=rxbuf[2];
		   break;
	    }
		case 0xd3:			  //��˿�ٶ�IPM
		{
		   W_speedIPM=(rxbuf[2]|(rxbuf[3]<<8));
		   W_speed=(W_speedIPM*127+251)/500;
		   if(Wire_feed==YES)
		   {
		     BYTE[0]=0X04;
		     BYTE[1]=(W_speed)&0XFF;
		     BYTE[2]=(W_speed)>>8;
		     send_Msg2(BYTE,3);
		   }
		   break;
		}
	    case 0x54:			  //MIG ���ӵ�ѹ
	    {

		   volt=(rxbuf[2])|(rxbuf[3]<<8);
		   break;
	    }
	    case 0x55:			   //MIG����
	    {

		   arc_length=rxbuf[2];
		   break;
	    }
	    case 0x56:			   //MIG ǰ��ʱ��
	    {

		   T_before=rxbuf[2];
		   break;
	    }
	    case 0x57:			   //MIG ����ʱ��
	    {

		   T_after=rxbuf[2];
		   break;
	    }
	    case 0x58:			   //MIG ��ʼʱ��
	    {

		   start_t=rxbuf[2];
		   break;
	    }
	    case 0x59:			   //MIG �ջ�ʱ��
	    {
	
		   stop_t=rxbuf[2];		    
		   break;
	    }
	    case 0x5A:			   //MIG ��ճ˿ʱ��
	    {
	    
		   break;
	    }
	    case 0x5B:			   //MIG ��ճ˿��ѹ
	    {
	    
	     	break;
	    }
	    case 0x5C:			   //MIG ����˿�ٶ�
	    {

		   SW_speed=rxbuf[2];	
		   break;
	    }
		case 0xdc:
	    {
	       SW_speedIPM=(rxbuf[2]|(rxbuf[3]<<8));
		   SW_speed=(SW_speedIPM*127+251)/500;
	    }
	    case 0x5d:			   //PMIG arclen adj gain
	    {
	   
	   
		   break;
	    }
	    case 0x5e:			   //MIGdual pulse wfspend
	    {
	   
	   	   break;
	    }
	    case 0x5f:			   //MIG ͦ��
	    {
	    
		   deflection=rxbuf[2];		
		   break;
	    }
	    case 0x60:			   //MIG material
	    {
	    
		   MAT=rxbuf[2];		
		   break;
	    }
	    case 0x61:			   //MIG ��ճ˿ǿ��
	    {
	    
		   strength=rxbuf[2];		
		   break;
	    }
	    case 0x63:			   //MIG ����/�Ĳ�����֡
	    {		
		   switch(rxbuf[2])
		    {	   
		      case 0x5A:
		       {
			     step=double_step;		  //����			  
			     break;
			   }
		      case 0xA5:		  //�Ĳ�
		       {
			     step=four_step;
			     break;
			   }
		      case 0xee:		  //�㺸
		       {
			     step=single_step;
			     break;
		       }
		    }		
		   break;
	     }
		 case 0x64:			   //MMA ����
		 {		    
		
			current=rxbuf[2]|(rxbuf[3]<<8); 
			break;
		 }
		 case 0x65:			   //MMA  ��������
		 {
			Arc_Current=rxbuf[2]; 	    
			break;
		 }
		 case 0x66:			   //MMA ��������
		 {
		    
			
			P_current=rxbuf[2]; 
			break;
		 }
		 case 0x67:			   //MMA �绡��Ӳ�����ڵ��ӵ翹
		 {
		    
		    
			break;
		 }
		 case 0x68:			   //MMA ����ʱ��
		 {
		    
			Arc_Time=rxbuf[2]; 
			break;
		 }
		 case 0x69:			   //MMA �յ��ѹ
		 {
		  
			K_volt=rxbuf[2];
			break;
		 }
		 case 0x6A:			   //���
		 {
		    indu=rxbuf[2];
			break;
		 }
		 case 0x6B:			   //MIG Start WFS
		 {
			
			start_wfs=rxbuf[2];	    
			break;
		 }
		 case 0x6C:			   //MIG Stop volt
		 {
		    
			break;
		 }
		 case 0x6D:			   //MIG Stop WFS
		 {
		    
			stop_wfs=rxbuf[2];	    
			break;
		 }
		 case 0x6E:			   //MIG Tack time
		 {
		  
			tack_time=rxbuf[2]; 
			break;
		 }
		 case 0x6F:			   //PMIG uref compensation coef
		 {
		  
			break;
		 }
		 case 0x70:			   //MIG pulse current
		 {
		  
			Pulse_current=rxbuf[2];	   
			break;
		 }
		 case 0x71:			   //MIG base current
		 {
		
			B_current=rxbuf[2];	    
			break;
		 }
		 case 0x72:			   //MIG pulse freq
		 {
		  
			frequency=rxbuf[2];		
			break;
		 }
		 case 0x73:			   //MIG dual pulse freq
		 {
		  
			dual_freq=rxbuf[2];	
			break;
		 }
		 case 0x74:			   //MIG ����΢��
		 {
		  
			arc_adj=rxbuf[2];		    
			break;
		 }
		 case 0x75:			   //MIG mid current
		 {
			mid_current=rxbuf[2];
			break;
		 }
		 case 0x76:			   //MIG ducycycle
		 {
		 
			break;
		 }
		 case 0x77:			   //p2 cvgain(���ɿ���) ������̼
		 {
		  	cvgain=rxbuf[2];
			break;
		 }
		 case 0x78:			   //p2 base current
		 {
		   
			SB_current=rxbuf[2];	    
			break;
		 }					   
		 case 0x7A:			   //p2 ��ѹ
		 {
		    
			S_volt=rxbuf[2];	
			break;
		 }
		 case 0x7B:			   //p2�绡����
		 {		    
	        arc_control=rxbuf[2];	
			break;
		 }
		 case 0x7C:			   //p2 ����
		 {
		    
	        S_freq=rxbuf[2];	
			break;
		 }
		 case 0x7D:			   //p2 ��ֵ���� current
		 {
		   
	        SP_current=rxbuf[2];	    
			break;
		 }
		 case 0x7f:
	     {

	     }
	}
 }
 switch(rxbuf[0])
  {
     case 0x1f:			   //lock
	 {
	   if(rxbuf[1]==0x05)
	    {
		   switch(rxbuf[2])
		    {
			  case 0:
			   {
//			     lock=0;
				 break;
			   }
			  case 1:
			   {
//			     lock=1;
				 break;
			   }
			} 
		}
	   break;
	 }
     case 0x01:			 //��λ֡
	 {	    
		MENU=first;
		break;
	 }	 
	 case 0x80:			   //1HZ����֡
	 {
	    switch(rxbuf[2])   //״̬
		{
		  case 0x4A:		   //����
		  {
			 if(status==weldding)
			 {
			    MENU=first;
				setting=NO;
				status=idle;
			 }
		     break;
		  }
		  case 0x55:		   //����
		  {
		     if(status==idle)
			 {
			    MENU=va_data;
				status=weldding;
			 }
		     break;
		  }
		}
		switch(rxbuf[3])	//ģʽ
		{
		  case 0x01:		  // pluse
		  {
			mode=mode_pluse;
		    break;
		  }
		  case 0x04:		  //CV
		  {
			mode=mode_CV;
		    break;
		  }
		  case 0x08:		  //CC
		  {	
		    mode=mode_CC;
		    break;
		  }
		  case 0x02:		  //SHORT
		  {	  
		    mode=mode_short;
		    break;
		  }
		  case 0x10:		  //MMA
		  {	
		    mode=mode_MMA;
		    break;
		  }
		}
	    if(rxbuf[4]==0)	       //����
		{
		  if(MENU==error)
		     MENU=first;
		}
		else				   //����
		{
		  MENU=error;
		}	 
		Speed_R=rxbuf[6];        //˿�ٷ���
	    break;
	 } 
	 case 0x81:			   //Ӧ��֡
	 {
	    
		break;
	 }
	 case 0x97:			   //���ӵ���/��ѹ����ֵ
	 {
	    C=(rxbuf[1])|(rxbuf[2]<<8);
		V=(rxbuf[3])|(rxbuf[4]<<8);
		break;
	 }
	 case 0x99:			   //0X98����֡
	 {
	    
		break;
	 }
	 case 0xA0:			   //(Broadcast)Failure alert
	 {
	    F_alert=rxbuf[1];
		MENU=error;
		break;
	 }	 
  }
}
