#include "sys.h"
#include "lib.h"
MOTOR_PARA XaxisPara,YaxisPara,ZaxisPara;
POSTION    XaxisPos,YaxisPos,ZaxisPos;
TICK_COUNT OscTimeCount;
//TRACK_SW   TrackSW;
DATA_FEEDBACK DataFeedback;
ERROR_FLAG    ErrorFlag;
OSC_TRACK     OscTrack;

#define SelBig(x,y)   (x>y?x:y)
#define SelSmall(x,y) (x<y?x:y)
#define SelBigAddr(x,y)   (x>y?&x:&y)
#define SelSmallAddr(x,y) (x<y?&x:&y)
#define SwitchSW(x)   (x==0x5a?1:0)

SWITCH_STATUS  SwitchStatus,PresentStatus;
TRAVEL_PARA    TravelPara;

static void EdgeSignalInit(void)
{
  RCC->APB2ENR|=1<<5;     //ʹ��PORTDʱ��
	GPIOD->CRH&=0xFFFF0000;	//PD8,9,10,11���ó�����
	GPIOD->CRH|=0x00008888;
	GPIOD->ODR|=0X0F<<8;
}	

void TIM5_PWM_Init(u16 arr,u16 psc)   //TIM5_CH4   ����
{		 					 
	//�˲������ֶ��޸�IO������
	RCC->APB1ENR|=1<<3; 	  //TIM5ʱ��ʹ��    
	RCC->APB2ENR|=1<<2;    	//ʹ��PORTAʱ��	

	GPIOA->CRL&=0XFFFF0FFF;	//PA3���
	GPIOA->CRL|=0X0000B000;	//���ù������ 	  	    

	TIM5->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM5->PSC=psc;			    //Ԥ��Ƶ������Ƶ	
	TIM5->CCR4=XaxisPW;     //ռ�ձ�����
	
	TIM5->CCMR2|=6<<12;  	  //CH4 PWMģʽ		 
	TIM5->CCMR2&=~(1<<11);  //CH4Ԥװ��ʹ��	   
	TIM5->CCER|=1<<12;   	  //OC4 ���ʹ��	ѡ������Ƚ�״̬   
	TIM5->CR1=0x0080;   	  //ARPEʹ�� 	
//  TIM5->CR1|=0x01;      //ʹ�ܶ�ʱ��5		
//	MY_NVIC_Init(1,3,TIM5_IRQn,2);
} 

void TIM3_PWM_Init(u16 arr,u16 psc)  //TIM3_CH1    ����
{		 					 
	//�˲������ֶ��޸�IO������
	RCC->APB1ENR|=1<<1; 	  //TIM3ʱ��ʹ��    
	RCC->APB2ENR|=1<<2;    	//ʹ��PORTAʱ��	

	
	GPIOA->CRL&=0XF0FFFFFF;	//PA6���
	GPIOA->CRL|=0X0B000000;	//���ù������ 	  	 
	   
	TIM3->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM3->PSC=psc;			    //Ԥ��Ƶ������Ƶ	
	TIM3->CCR1=YaxisPW;     //ռ�ձ�����
	
	TIM3->CCMR1|=6<<4;  	  //CH1 PWMģʽ		 
	TIM3->CCMR1&=~(1<<3);  	//CH1Ԥװ��ʹ��	   
	TIM3->CCER|=1<<0;   	  //OC1 ���ʹ��	ѡ������Ƚ�״̬   
	TIM3->CR1=0x0080;   	  //ARPEʹ�� 	

//  TIM3->DIER|=1<<0;	  	
//	MY_NVIC_Init(1,3,TIM3_IRQn,2);
} 
void TIM8_PWM_Init(u16 arr,u16 psc)  //TIM8_CH1   ����
{		 					 
	//�˲������ֶ��޸�IO������
	RCC->APB2ENR|=1<<13; 	  //TIM8ʱ��ʹ��    
	RCC->APB2ENR|=1<<4;    	//ʹ��PORTCʱ��	

	
	GPIOC->CRL&=0XF0FFFFFF;	//PC6���
	GPIOC->CRL|=0X0B000000;	//���ù������ 	  	 
	   
	TIM8->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM8->PSC=psc;			    //Ԥ��Ƶ������Ƶ	
	TIM8->CCR1=ZaxisPW;     //ռ�ձ�����
	
	TIM8->BDTR|=1<<15;
	TIM8->CCMR1|=6<<4;  	  //CH1 PWMģʽ		 
	TIM8->CCMR1&=~(1<<3);  	//CH1Ԥװ��ʹ��	   
	TIM8->CCER|=1<<0;   	  //OC1 ���ʹ��	ѡ������Ƚ�״̬   
	TIM8->CR1=0x0080;   	  //ARPEʹ�� 	

//  TIM8->DIER|=1<<0;	  	
//	MY_NVIC_Init(1,3,TIM8_IRQn,2);
} 

void TIM2_Capture_Init(u16 arr,u16 psc)  //TIM3_CH1
{
  RCC->APB1ENR|=1<<0; 	  //TIM3ʱ��ʹ��    
	RCC->APB2ENR|=1<<2;    	//ʹ��PORTAʱ��	
	GPIOA->CRL&=0XFFFFFFF0;	//PA6����
	GPIOA->CRL|=0X00000004;	//��������
	TIM2->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM2->PSC=psc;			    //Ԥ��Ƶ������Ƶ
	
	TIM2->CCMR1|=0<<12;
	TIM2->CCER|=0<<5;       //����/����2����

	TIM2->SMCR|=1<<14;      //�����ⲿʱ��Դ2
	TIM2->SMCR|=1<<15;      //�͵�ƽ���½��ش���
	
//	TIM2->DIER|=1<<2;
	TIM2->DIER|=1<<0;
	MY_NVIC_Init(1,3,TIM2_IRQChannel,2);
	
}
void TIM2_IRQHandler(void)				
{ 	 
  OSIntEnter();	
  if(TIM2->SR&0X0001)//����ж�
	{
		 if(XaxisPara.RemainStepNum)
		 {
		    SubCaptureSet(Xaxis,&XaxisPara.RemainStepNum);
		 }
	   else Motor_Stop(Xaxis);		
	}				    				   				     	    						   
	TIM2->SR&=~(1<<0);//����жϱ�־λ	
  OSIntExit();	
}
/*Sel can be Enable or Disable*/
void TIM2_Capture_Set(u16 arr,u8 Sel)   
{
  TIM2->ARR=arr;			    //�趨�������Զ���װֵ
  TIM2->CNT=0;	
	if(Sel==Enable)
	  TIM2->CR1|=1<<0;      //ʹ�ܶ�ʱ��3
	else if(Sel==Disable)
		TIM2->CR1&=~(1<<0);
}	

void TIM1_Capture_Init(u16 arr,u16 psc)   //���Ҽ���
{
  RCC->APB2ENR|=1<<11; 	  //TIM1ʱ��ʹ��    
	RCC->APB2ENR|=1<<6;    	//ʹ��PORTEʱ��	
	
	RCC->APB2ENR|=1<<0;     //��������ʱ��	   
	AFIO->MAPR&=0XFFFFFF3F; //���MAPR��[7:6]
	AFIO->MAPR|=3<<6;       //������ӳ��,TIM1_ETR->PE7
	
	GPIOE->CRL&=0X0FFFFFFF;	//PE7����
	GPIOE->CRL|=0X40000000;	//��������
	TIM1->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM1->PSC=psc;			    //Ԥ��Ƶ������Ƶ
	
	TIM1->CCMR1|=0<<12;
	TIM1->CCER|=0<<5;       //����/����2����

	TIM1->SMCR|=1<<14;      //�����ⲿʱ��Դ2
	TIM1->SMCR|=1<<15;      //�͵�ƽ���½��ش���
	
//	TIM1->DIER|=1<<2;
	TIM1->DIER|=1<<0;
	MY_NVIC_Init(1,3,TIM1_UP_IRQChannel,2);
}

void TIM1_UP_IRQHandler(void)				
{ 
	OSIntEnter();		    		  			    
  if(TIM1->SR&0X0001)//����ж�
	{		
		 if(YaxisPara.RemainStepNum)
		 {
		    SubCaptureSet(Yaxis,&YaxisPara.RemainStepNum);
		 }	
     else	 Motor_Stop(Yaxis);     		
	}				    				   				     	    						   
	TIM1->SR&=~(1<<0);//����жϱ�־λ
  OSIntExit();	
  
}
/*Sel can be Enable or Disable*/
void TIM1_Capture_Set(u16 arr,u8 Sel)   
{
  TIM1->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM1->CNT=0;
	if(Sel==Enable)
	  TIM1->CR1|=1<<0;      //ʹ�ܶ�ʱ��3
	else if(Sel==Disable)
		TIM1->CR1&=~(1<<0);
}	

void TIM4_Capture_Init(u16 arr,u16 psc)   //���¼���
{
  RCC->APB1ENR|=1<<2; 	  //TIM4ʱ��ʹ��    
	RCC->APB2ENR|=1<<6;    	//ʹ��PORTEʱ��	
	
	GPIOE->CRL&=0XFFFFFFF0;	//PE0����
	GPIOE->CRL|=0X00000004;	//��������
	TIM4->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM4->PSC=psc;			    //Ԥ��Ƶ������Ƶ
	
	TIM4->CCMR1|=0<<12;
	TIM4->CCER|=0<<5;       //����/����2����

	TIM4->SMCR|=1<<14;      //�����ⲿʱ��Դ2
	TIM4->SMCR|=1<<15;      //�͵�ƽ���½��ش���
	
//	TIM4->DIER|=1<<2;
	TIM4->DIER|=1<<0;
	MY_NVIC_Init(1,3,TIM4_IRQChannel,2);
}
void TIM4_IRQHandler(void)				
{ 	  
  OSIntEnter();	
  if(TIM4->SR&0X0001)//����ж�
	{		
		 if(ZaxisPara.RemainStepNum)
		 {
		    SubCaptureSet(Zaxis,&ZaxisPara.RemainStepNum);
		 }	
     else	 Motor_Stop(Zaxis);     		
	}				    				   				     	    						   
	TIM4->SR&=~(1<<0);//����жϱ�־λ
  OSIntExit();	
}
/*Sel can be Enable or Disable*/
void TIM4_Capture_Set(u16 arr,u8 Sel)   
{
  TIM4->ARR=arr;			    //�趨�������Զ���װֵ 
	TIM4->CNT=0;
	if(Sel==Enable)
	  TIM4->CR1|=1<<0;      //ʹ�ܶ�ʱ��3
	else if(Sel==Disable)
		TIM4->CR1&=~(1<<0);
}	

void Motor_Init(void)
{	
	RCC->APB2ENR|=1<<4;                //ʹ��PORTCʱ��
	RCC->APB2ENR|=1<<2;                //ʹ��PORTAʱ��
	RCC->APB2ENR|=1<<3;                //ʹ��PORTEʱ��
	/*X-axis:XPUL->>PA3  XDIR->>PA4  XENA->>PA5*/	
	GPIOA->CRL&=0XFF00FFFF;	           //PA4,5���óɳ�	
	GPIOA->CRL|=0X00330000;	
	GPIOA->ODR|=1<<5;		               //PA5 ����
  TIM5_PWM_Init(XaixsStartARR,XaxisPSC);      //PWMƵ��=72000000/((1199+1)*(11+1))=5000HZ	
//TIM3_Capture_Init(0XFFFF,XaxisCapPSC);      //TIM3_CH1
	
	/*Y-axis:YPUL->>PA6  YENA->>PC5  YDIR->>PC4*/	
	GPIOC->CRL&=0XFF00FFFF;	           //PC4,5���óɳ�	
	GPIOC->CRL|=0X00330000;	
	GPIOC->ODR|=3<<4;		               //PC4,5 ����
  TIM3_PWM_Init(YaixsStartARR,YaxisPSC);      //PWMƵ��=72000000/((1199+1)*(11+1))=5000HZ	
	TIM1_Capture_Init(0XFFFF,YaxisCapPSC);            //TIM3_CH1

  /*Z-axis:ZPUL->>PC6   ZENA->>PB2   ZDIR->>PB1*/	
	GPIOB->CRL&=0XFFFFF00F;	           //PB1,2���óɳ�	
	GPIOB->CRL|=0X00000330;	
	GPIOB->ODR|=1<<2;		               //PB2 ����
  TIM8_PWM_Init(ZaixsStartARR,ZaxisPSC);      //PWMƵ��=72000000/((1199+1)*(11+1))=5000HZ	
  TIM4_Capture_Init(0XFFFF,ZaxisCapPSC);
  PostionCall();
	EdgeSignalInit();
}	
/*�ֲ���������*/
u8 SubCaptureSet(u8 dimension,u32* ReaminStepNum)
{	
	u8  Sign=0; u32 RecordENA;
  switch(dimension)
  {
/*		case Xaxis:
			XaxisPara.SubStepNum=*ReaminStepNum;
			RecordENA=XaxisENA;
			XaxisENA&=MotorDisable;
			if(*ReaminStepNum/65535)
      {
			  *ReaminStepNum-=65535;
				XaxisPara.SubStepNum=65535;
			}	
			else *ReaminStepNum=NULL;
      XaxisCapSet(XaxisPara.SubStepNum,Enable);
      XaxisENA=RecordENA;			
		break;*/
			
		case Yaxis:
			YaxisPara.SubStepNum=*ReaminStepNum;
			RecordENA=YaxisENA;
		  YaxisENA&=MotorDisable;
			if(*ReaminStepNum/65535)
      {
			  *ReaminStepNum-=65535;
				YaxisPara.SubStepNum=65535;
			}	
			else *ReaminStepNum=NULL;
      YaxisCapSet(YaxisPara.SubStepNum,Enable);	
			YaxisENA=RecordENA; 
		break;
		
		case Zaxis:			
		  ZaxisPara.SubStepNum=*ReaminStepNum;
			RecordENA=ZaxisENA;
		  ZaxisENA&=MotorDisable;
			if(*ReaminStepNum/65535)
      {
			  *ReaminStepNum-=65535;
				ZaxisPara.SubStepNum=65535;
			}	
			else *ReaminStepNum=NULL;
      ZaxisCapSet(ZaxisPara.SubStepNum,Enable);	
			ZaxisENA=RecordENA; 
		break;
	}
  return Sign;	
}	
/*parm dimension can be Xaxis,Yaxis or Zaxis*/
/*parm dir can be LiftDir or RightDir*/
void Motor_Start(u8 dir,u8 dimension,u32* ReaminStepNum)
{
	switch(dimension)
  {
		case Xaxis:
			XaxisENA&=MotorDisable;
		  XaxisStepNum=NULL;
//			memset(&XaxisPara,0,sizeof(XaxisPara));
		  XaxisPara.ExecuteFreq=XaxisStartFreq;
		  XaxisDIR=dir;
		  Motor_FreqSetting(Xaxis,XaxisPara.ExecuteFreq);
		  SubCaptureSet(dimension,ReaminStepNum);
		  XaxisPara.Status=Operation;
		  XaxisENA|=MotorEnable;
      XaxisBrake=NULL;	  
		break;
		 
		case Yaxis:
			YaxisENA&=MotorDisable;
		  YaxisStepNum=NULL;
//			memset(&YaxisPara,0,sizeof(YaxisPara));
		  YaxisPara.ExecuteFreq=YaxisStartFreq;
			YaxisDIR=dir;
		  Motor_FreqSetting(Yaxis,YaxisPara.ExecuteFreq);
		  SubCaptureSet(dimension,ReaminStepNum);
		  YaxisPara.Status=Operation;
		  YaxisENA|=MotorEnable; 		  
		break;
		
		case Zaxis:
			ZaxisENA&=MotorDisable;
		  ZaxisStepNum=NULL;
//			memset(&ZaxisPara,0,sizeof(ZaxisPara));
		  ZaxisPara.ExecuteFreq=ZaxisStartFreq;
			ZaxisDIR=dir;
		  Motor_FreqSetting(Zaxis,ZaxisPara.ExecuteFreq);
		  SubCaptureSet(dimension,ReaminStepNum);
		  ZaxisPara.Status=Operation;
		  ZaxisENA|=MotorEnable;
		  
		break;
	}		
}	
void Motor_Stop(u8 dimension)
{
	POSTION Postion;
  switch(dimension)
  {
		case Xaxis:
		  XaxisENA&=MotorDisable;		
      if(XaxisStepNum==NULL)
         XaxisPara.RunStepNum=XaxisPara.RecordStepNum;		
      else 			
         XaxisPara.RunStepNum=XaxisPara.RecordStepNum-XaxisPara.SubStepNum+XaxisStepNum;	
		  if(XaxisPara.Direction==RightDir)
		     XaxisPara.RecordTotStepNum-=XaxisPara.RunStepNum;
			else 
				 XaxisPara.RecordTotStepNum+=XaxisPara.RunStepNum;
			XaxisCapSet(0,Disable);
      XaxisPara.ShiftSign=Constant;	
      XaxisPara.TotalStepNum=NULL;	
      XaxisPara.RemainStepNum=NULL;	
      XaxisPara.SubStepNum=NULL;
      XaxisPara.Status=Suspend;
      XaxisBrake=TRUE;			
		break;
		 
		case Yaxis:
		  YaxisENA&=MotorDisable;	
      if(YaxisStepNum==NULL)
         YaxisPara.RunStepNum=YaxisPara.RecordStepNum;		
      else 			
         YaxisPara.RunStepNum=YaxisPara.RecordStepNum-YaxisPara.SubStepNum+YaxisStepNum;
      if(YaxisPara.Direction==RightDir)
		     YaxisPara.RecordTotStepNum-=YaxisPara.RunStepNum;
			else 
				 YaxisPara.RecordTotStepNum+=YaxisPara.RunStepNum;
			YaxisCapSet(0,Disable);
      Postion.SourcePos=YaxisPos.SourcePos;
			YaxisPos.SourcePos=YaxisPos.TargetPos;
			YaxisPos.TargetPos=Postion.SourcePos;
			YaxisPara.ShiftSign=Constant;
			YaxisPara.TotalStepNum=NULL;	
      YaxisPara.RemainStepNum=NULL;	
			YaxisPara.SubStepNum=NULL;
			YaxisPara.Status=Suspend;
		break;
		
		case Zaxis:
		  ZaxisENA&=MotorDisable;		
      if(ZaxisStepNum==NULL)
         ZaxisPara.RunStepNum=ZaxisPara.RecordStepNum;		
      else 			
         ZaxisPara.RunStepNum=ZaxisPara.RecordStepNum-ZaxisPara.SubStepNum+ZaxisStepNum;
      if(ZaxisPara.Direction==RightDir)
		     ZaxisPara.RecordTotStepNum-=ZaxisPara.RunStepNum;
			else 
				 ZaxisPara.RecordTotStepNum+=ZaxisPara.RunStepNum;
			ZaxisCapSet(0,Disable);
			ZaxisPara.ShiftSign=Constant;
			ZaxisPara.TotalStepNum=NULL;	
      ZaxisPara.RemainStepNum=NULL;	
			ZaxisPara.SubStepNum=NULL;
			ZaxisPara.Status=Suspend;
		break;
	}	 
}	
void Motor_FreqSetting(u8 dimension,u32 Freq)
{
  switch(dimension)
  {
		case Xaxis:
		  XaxisARR=CoreFreq/(Freq*(XaxisPSC+1))-1;
		break;
		 
		case Yaxis:
		  YaxisARR=CoreFreq/(Freq*(YaxisPSC+1))-1; 		  
		break;
		
		case Zaxis:
		  ZaxisARR=CoreFreq/(Freq*(ZaxisPSC+1))-1; 
		break;
	}		
}
void Motor_SpeedSetting(u32 RunSpeed)
{
	XaxisCCR=(RunSpeed*XaxisARR*0.237)/(float)((float)((float)(MaxRspeed/Ratio)*Perimeter)/60);
//	XaxisCCR=XaxisARR;
}	
static u8 MotorSetMmaMove(u8 Direction,u32 RunSpeed,u8 dimension,MOTOR_PARA* MotorPara)
{
	u32 StartSpeed,Cyclestep,Pitch,Microstep;
	switch(dimension)
	{
	  case Xaxis:
		  StartSpeed=XaxisStartSpeed;
		  Cyclestep=XaxisCyclestep;
		  Pitch=XaxisPitch;
		  Microstep=XaxisMicrostep;
		  Motor_SpeedSetting(RunSpeed);
		  MotorPara->ACC=XaxisAcc;
		break;
		 
		case Yaxis:
		  StartSpeed=YaxisStartSpeed;
		  Cyclestep=YaxisCyclestep;
		  Pitch=YaxisPitch;
		  Microstep=YaxisMicrostep; 
      MotorPara->ACC=YaxisAcc;		
		break;
		
		case Zaxis:
		  StartSpeed=ZaxisStartSpeed;
		  Cyclestep=ZaxisCyclestep;
		  Pitch=ZaxisPitch;
		  Microstep=ZaxisMicrostep;
      MotorPara->ACC=ZaxisAcc;		
		break;
	}	
	MotorPara->ExecuteSpeed=StartSpeed;
	MotorPara->DecStepNum=Infinity;
	MotorPara->TotalStepNum=Infinity;
	MotorPara->RunFreq=(Cyclestep*RunSpeed*Microstep)/Pitch;
	MotorPara->RemainStepNum=MotorPara->TotalStepNum;
	Motor_Start(Direction,dimension,&MotorPara->RemainStepNum);
	MotorPara->ShiftSign=Accelerate;
	return 1;
}
/*You can set auto swing mode or straight line mode*/
/*swing mode: set RunSpeed to NULL*/
/*straight line mode:set RunSpeed value, set SwingFreq and HoldTime to NULL*/
static u8 MotorSetAutoMove(int SourcePos,int TargetPos,float SwingFreq,u32 RunSpeed,float HoldTime,u8 dimension,MOTOR_PARA* MotorPara)  //���뵥λ0.01mm��ʱ�䵥λs
{
  u32 StartSpeed,Cyclestep,Pitch,Microstep;		
	int ParaA; double ParaB,ParaC,Delta;
  switch(dimension)
  {
		case Xaxis:		  
			StartSpeed=XaxisStartSpeed;
		  Cyclestep=XaxisCyclestep;
		  Pitch=XaxisPitch;
		  Microstep=XaxisMicrostep;
		  MotorPara->ACC=XaxisAcc;
		break;
		 
		case Yaxis:		  
			StartSpeed=YaxisStartSpeed;
		  Cyclestep=YaxisCyclestep;
		  Pitch=YaxisPitch;
		  Microstep=YaxisMicrostep; 
      MotorPara->ACC=YaxisAcc;		
		break;
		
		case Zaxis:
			StartSpeed=ZaxisStartSpeed;
		  Cyclestep=ZaxisCyclestep;
		  Pitch=ZaxisPitch;
		  Microstep=ZaxisMicrostep;
		  MotorPara->ACC=ZaxisAcc;
		break;
	}			
	MotorPara->Offset=(int)(SourcePos-TargetPos);
  if(MotorPara->Offset==NULL) return 0;	
	if(MotorPara->Offset>0)    //����
		MotorPara->Direction=RightDir;
	else 
		MotorPara->Direction=LiftDir;
	MotorPara->Offset=abs(MotorPara->Offset);
	if(RunSpeed==NULL)
	{	
		do{MotorPara->Period=(float)1/SwingFreq;
	  MotorPara->RunTime=(float)((float)(MotorPara->Period/2)-HoldTime);
		/*RunSpeed=((2*v0+at)+sqrt(pow(a*vo+at,2)-4*(pow(v0,2)+as)))/2*/	
    ParaA=1; ParaB=-((double)2*StartSpeed+(double)MotorPara->ACC*MotorPara->RunTime);
    ParaC=(double)pow(StartSpeed,2)+(double)MotorPara->ACC*MotorPara->Offset;
    Delta=(double)pow(ParaB,2)-(double)4*ParaA*ParaC;
		MotorPara->ACC+=AccDelta;}
    while((Delta<0)&&((MotorPara->ACC)<YaxisMaxAcc)); 
		if(Delta<0) return ERROR_YaxisAcc;			
    MotorPara->RunSpeed=(-ParaB-sqrt(Delta))/2;	
    MotorPara->ACC-=AccDelta;		
	}
  else MotorPara->RunSpeed=RunSpeed;	
	MotorPara->ExecuteSpeed=StartSpeed;
	MotorPara->RunFreq=(Cyclestep*MotorPara->RunSpeed*Microstep)/Pitch;
	MotorPara->DecOffset=MotorPara->Offset-(pow(MotorPara->RunSpeed,2)-pow(StartSpeed,2))/(2*MotorPara->ACC);			
	MotorPara->TotalStepNum=(Cyclestep*MotorPara->Offset*Microstep)/Pitch;				
	MotorPara->DecStepNum=(Cyclestep*MotorPara->DecOffset*Microstep)/Pitch;		
	MotorPara->RemainStepNum=MotorPara->TotalStepNum;
	Motor_Start(MotorPara->Direction,dimension,&MotorPara->RemainStepNum);
	MotorPara->ShiftSign=Accelerate;
	return 0;
}	

void MotorShiftTask(void)
{	
  if(YaxisPara.ShiftSign==Accelerate)
	{
	   if(YaxisPara.ExecuteSpeed<YaxisPara.RunSpeed)
		 {	
        YaxisPara.ExecuteSpeed+=(YaxisPara.ACC/Tim7Freq);			          			 
		 }	
		 else 
		 {
			  YaxisPara.ExecuteSpeed=YaxisPara.RunSpeed;
			  YaxisPara.ShiftSign=Decelerate;
		 }
     YaxisPara.ExecuteFreq=(YaxisCyclestep*YaxisPara.ExecuteSpeed*YaxisMicrostep)/YaxisPitch;	
     Motor_FreqSetting(Yaxis,YaxisPara.ExecuteFreq);		 		    		 
	}	
  else if(YaxisPara.ShiftSign==Decelerate)
	{
	   if((YaxisPara.RunStepNum>=YaxisPara.DecStepNum)&&(YaxisPara.ExecuteSpeed>YaxisStartSpeed))
		 {	 
			  YaxisPara.ExecuteSpeed-=(YaxisPara.ACC/Tim7Freq);			 
        YaxisPara.ExecuteFreq=(YaxisCyclestep*YaxisPara.ExecuteSpeed*YaxisMicrostep)/YaxisPitch;	
			  Motor_FreqSetting(Yaxis,YaxisPara.ExecuteFreq);
		 }	 	 
	}
	
	if(ZaxisPara.ShiftSign==Accelerate)
	{
	   if(ZaxisPara.ExecuteSpeed<ZaxisPara.RunSpeed)
		 {	
        ZaxisPara.ExecuteSpeed+=(ZaxisPara.ACC/Tim7Freq);			         			 
		 }	
		 else 
		 {
			  ZaxisPara.ShiftSign=Decelerate;
		    ZaxisPara.ExecuteSpeed=ZaxisPara.RunSpeed;
     }			 
		 ZaxisPara.ExecuteFreq=(ZaxisCyclestep*ZaxisPara.ExecuteSpeed*ZaxisMicrostep)/ZaxisPitch;	
     Motor_FreqSetting(Zaxis,ZaxisPara.ExecuteFreq); 
	}
  else if(ZaxisPara.ShiftSign==Decelerate)
	{
	   if((ZaxisPara.RunStepNum>=ZaxisPara.DecStepNum)&&(ZaxisPara.ExecuteSpeed>ZaxisStartSpeed))
		 {	 
			  ZaxisPara.ExecuteSpeed-=(ZaxisPara.ACC/Tim7Freq);			 
        ZaxisPara.ExecuteFreq=(ZaxisCyclestep*ZaxisPara.ExecuteSpeed*ZaxisMicrostep)/ZaxisPitch;	
			  Motor_FreqSetting(Zaxis,ZaxisPara.ExecuteFreq);
		 }	 	 
	}		
}	

static u8 HightCtrlProcess(void)
{
	u8 MotionFlag=0,HightAdjFlag;
	if(ZaxisPara.Status==Operation) return 0; 
	ZaxisPos.RecordPos=(ZaxisPara.RecordTotStepNum*ZaxisPitch)/(ZaxisCyclestep*ZaxisMicrostep);
  if((PresentStatus.AutoTrack&Flag_HightTrack)==Flag_HightTrack)
  {
	  if(OscTrack.HightCtrl.ReciveFlag==TRUE) 
	  {	 
		  OscTrack.HightCtrl.ReciveFlag=NULL;
		  ZaxisPos.TargetPos=OscTrack.HightCtrl.ReciveData;
			ZaxisPara.RunSpeed=ZaxisTrackSpeed;
			MotionFlag=TRUE;
	  }
  }
	HightAdjFlag=(unsigned char)OSMboxAccept(msg_HightAdj); 
	switch(HightAdjFlag)
	{
	  case Adj_HightUp:
			ZaxisPara.RunSpeed=ZaxisTrackSpeed;
			ZaxisPos.TargetPos=ZaxisPos.RecordPos+TravelPara.VertiInc.ParaValue;
		  MotionFlag=TRUE;
		  break;
		case Adj_HightDown:
			ZaxisPara.RunSpeed=ZaxisTrackSpeed;
			ZaxisPos.TargetPos=ZaxisPos.RecordPos-TravelPara.VertiInc.ParaValue;
		  MotionFlag=TRUE;
		  break;
	}
	if(MotionFlag==TRUE)
	  ErrorFlag.TrackErrorCode=MotorSetAutoMove(ZaxisPos.RecordPos,ZaxisPos.TargetPos,NULL,ZaxisPara.RunSpeed,NULL,Zaxis,&ZaxisPara);	
}	

u8 AutoSwingTask(void)
{
	MOTOR_PARA  MotorPara;
	POSTION     Postion;
	int         RightPos,LiftPos,TargetPos,SourcePos;
	int         *BigPos,*SmallPos;
	u8          MotionFlag=0,OscAdjFlag;		
	if(ErrorFlag.TrackErrorCode!=NULL)  return 0;	
	if(YaxisPara.Status==Operation) return 0; 
	YaxisPos.RecordPos=(YaxisPara.RecordTotStepNum*YaxisPitch)/(YaxisCyclestep*YaxisMicrostep);
  OscTimeCount.HoldTime=TravelPara.HoldTime.ParaValue; 	
  switch(PresentStatus.OscSwitch)
	{
	  case StartOsc:	      			
		   YaxisPos.CentrePos=YaxisPos.RecordPos;
		   RightPos=YaxisPos.CentrePos-TravelPara.OscWidth.ParaValue/2;
		   LiftPos=YaxisPos.CentrePos+TravelPara.OscWidth.ParaValue/2;	
		   if(RightPos<=0)  return ERROR_YaxisPos;
		   YaxisPos.PdRightPos=RightPos;
		   YaxisPos.PdLiftPos=LiftPos;				   
		   YaxisPos.TempSouPos=YaxisPos.CentrePos;
       YaxisPos.TempTarPos=YaxisPos.PdRightPos;
		   YaxisPos.SourcePos=YaxisPos.PdLiftPos;
		   YaxisPos.TargetPos=YaxisPos.PdRightPos;
		   MotorPara.SwingFreq=(float)TravelPara.OscFreq.ParaValue;    //�𲽼��ٶȹ��󣬹ʼ���Ƶ��	
       MotorPara.HoldTime=(float)TravelPara.HoldTime.ParaValue/2;
       PresentStatus.OscSwitch=Oscing;	
		   MotionFlag=TRUE;
		break;
		
		case Oscing:		 
			 switch(SetTimer(&OscTimeCount))
       {
			   case ClockInit:
					 if((PresentStatus.AutoTrack&Flag_OscTrack)==Flag_OscTrack) CanTxFlag.EdgeSign=TRUE;
				   	          					 					 	
				   break;
				 case ClockTimeout:
					 MotorPara.SwingFreq=TravelPara.OscFreq.ParaValue;
					 MotorPara.HoldTime=TravelPara.HoldTime.ParaValue;				 
           YaxisPos.TempSouPos=YaxisPos.SourcePos;          
           OscAdjFlag=(unsigned char)OSMboxAccept(msg_OscAdj);  
           if((OscAdjFlag==NULL)&&((PresentStatus.AutoTrack&Flag_OscTrack)==Flag_OscTrack))
           {
             if(OscTrack.OscCtrl.ReciveFlag==TRUE) 
						 {	 
							 OscTrack.OscCtrl.ReciveFlag=NULL;
							 YaxisPos.TargetPos=OscTrack.OscCtrl.ReciveData;
						 }
           }				 
           switch(OscAdjFlag)
           {
					   case Adj_HorizLift:
							 if(YaxisPara.Direction==LiftDir)
							 {	 
							   YaxisPos.SourcePos+=TravelPara.HorizInc.ParaValue;
						     YaxisPos.TargetPos+=TravelPara.HorizInc.ParaValue;
							 }
               else OSMboxPost(msg_OscAdj,(void*)OscAdjFlag);							 
						   break;
						 case Adj_HorizRight:
							 if(YaxisPara.Direction==RightDir)
							 {	 
							   YaxisPos.SourcePos-=TravelPara.HorizInc.ParaValue;
						     YaxisPos.TargetPos-=TravelPara.HorizInc.ParaValue;
							 }	
               else OSMboxPost(msg_OscAdj,(void*)OscAdjFlag);							 
						   break;
						 case Adj_WidthInc:
							 BigPos=SelBigAddr(YaxisPos.SourcePos,YaxisPos.TargetPos);
						   SmallPos=SelSmallAddr(YaxisPos.SourcePos,YaxisPos.TargetPos);
						   *BigPos+=(float)TravelPara.WidthInc.ParaValue/2;
						   *SmallPos-=(float)TravelPara.WidthInc.ParaValue/2;
						   break;
						 case Adj_WidthDec:
							 BigPos=SelBigAddr(YaxisPos.SourcePos,YaxisPos.TargetPos);
						   SmallPos=SelSmallAddr(YaxisPos.SourcePos,YaxisPos.TargetPos);
						   *BigPos-=(float)TravelPara.WidthInc.ParaValue/2;
						   *SmallPos+=(float)TravelPara.WidthInc.ParaValue/2;
						   break;
					 }				 
					 YaxisPos.TempTarPos=YaxisPos.TargetPos;
					 YaxisPos.PdLiftPos=SelBig(YaxisPos.SourcePos,YaxisPos.TargetPos);
					 YaxisPos.PdRightPos=SelSmall(YaxisPos.SourcePos,YaxisPos.TargetPos);
					 YaxisPos.CentrePos=(YaxisPos.PdLiftPos+YaxisPos.PdRightPos)/2;					 
					 MotionFlag=TRUE;		
				   break;			 
			 }				 		   	 
		break;
		
		case StopOsc:
			 if(SetTimer(&OscTimeCount)!=ClockTimeout) return 0;
			 YaxisPos.TargetPos=YaxisPos.CentrePos;
		   YaxisPos.TempSouPos=YaxisPos.SourcePos;
       YaxisPos.TempTarPos=YaxisPos.TargetPos;
			 MotorPara.SwingFreq=(float)TravelPara.OscFreq.ParaValue;		//ͣ�����ٶȹ��󣬹�Ƶ�ʼ���																																																												
		   MotorPara.HoldTime=TravelPara.HoldTime.ParaValue/2;
		   PresentStatus.OscSwitch=NULL;
		   memset(&OscTrack,0,sizeof(OscTrack));
       MotionFlag=TRUE;		
		break;
	}		
	if(MotionFlag==TRUE)
    ErrorFlag.TrackErrorCode=MotorSetAutoMove(YaxisPos.TempSouPos,YaxisPos.TempTarPos,MotorPara.SwingFreq,NULL,MotorPara.HoldTime,Yaxis,&YaxisPara);
	if(ErrorFlag.TrackErrorCode==ERROR_YaxisAcc) return ERROR_YaxisAcc;
}	

void AutoOscTask(void)
{
	HightCtrlProcess();
  AutoSwingTask();
}	

u8 SetTimer(TICK_COUNT* HoldTimeCount)  
{
	int Delta_T;
  switch(HoldTimeCount->ClockStatus)
	{
		 case NULL:
			 HoldTimeCount->ClockStatus=ClockInit;
		 break;	 
		 case ClockInit:			   
			 HoldTimeCount->ClockStatus=ClockWait;
			 HoldTimeCount->RecordTick=TimeOverFlow.TickCount;
			 HoldTimeCount->TargetTick=(HoldTimeCount->RecordTick+(unsigned int)(HoldTimeCount->HoldTime*1000))%TimeoutTick;		 
		 break;
		 
		 case ClockWait:
			 Delta_T=TimeOverFlow.TickCount-HoldTimeCount->TargetTick;
		   if((Delta_T>=0)&&(Delta_T<MaxHoldTime))
			   HoldTimeCount->ClockStatus=ClockTimeout;	 
		 break;
			 
		 case ClockTimeout:
       HoldTimeCount->ClockStatus=NULL;
     break;		 
	}
  return HoldTimeCount->ClockStatus;
}	
	
u8 PostionStore(u32 XrecordTotStepNum,u32 YrecordTotStepNum,u32 ZrecordTotStepNum)
{
//  FM24CLXX_WriteLenByte(ADDR_XaxisPos,XrecordTotStepNum,LEN_XaxisPos);
	FM24CLXX_WriteLenByte(ADDR_YaxisPos,YrecordTotStepNum,LEN_YaxisPos);
	FM24CLXX_WriteLenByte(ADDR_ZaxisPos,ZrecordTotStepNum,LEN_ZaxisPos);
}	
u8 PostionCall(void)
{
//	XaxisPara.RecordTotStepNum=FM24CLXX_ReadLenByte(ADDR_XaxisPos,LEN_XaxisPos);	
	YaxisPara.RecordTotStepNum=FM24CLXX_ReadLenByte(ADDR_YaxisPos,LEN_YaxisPos);  
	ZaxisPara.RecordTotStepNum=FM24CLXX_ReadLenByte(ADDR_ZaxisPos,LEN_ZaxisPos);
}	

static u8 PostionInit(u8 dimension)
{
	switch(dimension)
	{
	  case Xaxis:
		  FM24CLXX_WriteLenByte(ADDR_XaxisPos,0,LEN_XaxisPos);
      XaxisPara.RecordTotStepNum=FM24CLXX_ReadLenByte(ADDR_XaxisPos,LEN_XaxisPos);
		break;
		 
		case Yaxis:
		  FM24CLXX_WriteLenByte(ADDR_YaxisPos,0,LEN_YaxisPos);
      YaxisPara.RecordTotStepNum=FM24CLXX_ReadLenByte(ADDR_YaxisPos,LEN_YaxisPos); 	  
		break;
		
		case Zaxis:
		  FM24CLXX_WriteLenByte(ADDR_ZaxisPos,0,LEN_ZaxisPos);
      ZaxisPara.RecordTotStepNum=FM24CLXX_ReadLenByte(ADDR_ZaxisPos,LEN_ZaxisPos);
		break;
	}	
}	

u8 StepCounterTask(void)  
{	
//	if((YaxisPara.Status!=Operation)&&(XaxisPara.Status!=Operation)&&(ZaxisPara.Status!=Operation)) return 0;
#if 0	
  XaxisPara.RecordStepNum=XaxisPara.TotalStepNum-XaxisPara.RemainStepNum;
	XaxisPara.RunStepNum=XaxisPara.RecordStepNum-XaxisPara.SubStepNum+XaxisStepNum;		
	if(XaxisPara.Direction==RightDir)
		XaxisPara.PresentTotStepNum=XaxisPara.RecordTotStepNum-XaxisPara.RunStepNum;
	else 
		XaxisPara.PresentTotStepNum=XaxisPara.RecordTotStepNum+XaxisPara.RunStepNum;
#endif		
	YaxisPara.RecordStepNum=YaxisPara.TotalStepNum-YaxisPara.RemainStepNum;
	YaxisPara.RunStepNum=YaxisPara.RecordStepNum-YaxisPara.SubStepNum+YaxisStepNum;		
	if(YaxisPara.Direction==RightDir)
		YaxisPara.PresentTotStepNum=YaxisPara.RecordTotStepNum-YaxisPara.RunStepNum;
	else 
		YaxisPara.PresentTotStepNum=YaxisPara.RecordTotStepNum+YaxisPara.RunStepNum;

	
	ZaxisPara.RecordStepNum=ZaxisPara.TotalStepNum-ZaxisPara.RemainStepNum;
	ZaxisPara.RunStepNum=ZaxisPara.RecordStepNum-ZaxisPara.SubStepNum+ZaxisStepNum;		
	if(ZaxisPara.Direction==RightDir)
		ZaxisPara.PresentTotStepNum=ZaxisPara.RecordTotStepNum-ZaxisPara.RunStepNum;
	else 
		ZaxisPara.PresentTotStepNum=ZaxisPara.RecordTotStepNum+ZaxisPara.RunStepNum; 	
}	

void PosRecordTask(void)
{
   XaxisPos.PresentPos=(XaxisPara.PresentTotStepNum*XaxisPitch)/(XaxisCyclestep*XaxisMicrostep);
	 YaxisPos.PresentPos=(YaxisPara.PresentTotStepNum*YaxisPitch)/(YaxisCyclestep*YaxisMicrostep);
	 ZaxisPos.PresentPos=(ZaxisPara.PresentTotStepNum*ZaxisPitch)/(ZaxisCyclestep*ZaxisMicrostep);
	 ////////////��FRAM�м�¼λ��/////////////////////////	
	 PostionStore(XaxisPara.RecordTotStepNum,YaxisPara.RecordTotStepNum,ZaxisPara.RecordTotStepNum);
	 ////////////�������������///////////////////////////
}	

void _SwitchCheckTask(void)
{
	u8  AdjFlag;
	switch(SwitchStatus.WeldingStatus)
  {
	  case SwitchOn:
			if(PresentStatus.WeldingStatus==NULL)
			{
			  PresentStatus.WeldingStatus=StartArc;
				SwitchStatus.WeldingStatus=NULL;
			}	
		  break;
		case SwitchOff:
			PresentStatus.WeldingStatus=NULL;
			PresentStatus.OscSwitch=StopOsc;
			SwitchStatus.WeldingStatus=NULL;
		  break;
	}	
  switch(SwitchStatus.CycleStatus)
  {
	  case SwitchOn:
      if(PresentStatus.CycleStatus==StopCycle)
			{
			  PresentStatus.CycleStatus=StartCycle;
				SwitchStatus.CycleStatus=NULL;
			}
      break;
    case SwitchOff:
			Motor_Stop(Xaxis);
			PresentStatus.CycleStatus=StopCycle;
			SwitchStatus.CycleStatus=NULL;
		  break;		
	}		
	switch(SwitchStatus.AutoTrack)
  {
	  case Osc_Track:
			PresentStatus.AutoTrack=Flag_OscTrack;
			SwitchStatus.AutoTrack=NULL;
      break;
		case Hight_Track:
			PresentStatus.AutoTrack=Flag_HightTrack;
			SwitchStatus.AutoTrack=NULL;
      break;
		case Both_Track:
			PresentStatus.AutoTrack=Flag_BothTrack;
			SwitchStatus.AutoTrack=NULL;
      break;
    case Off_Track:			
			PresentStatus.AutoTrack=NULL;
			SwitchStatus.AutoTrack=NULL;
		  break;		
	}
  switch(SwitchStatus.HorizStatus)
  {
	  case SwitchOn:
			if(PresentStatus.HorizStatus==StopRun)
			{
				YaxisPara.RunSpeed=TravelPara.HorizSpeed.ParaValue;
				YaxisPara.Direction=SwitchSW(SwitchStatus.HorizDir);
				if((YaxisPara.EdgeStatus>>YaxisPara.Direction)==0x01) break;
		    MotorSetMmaMove(YaxisPara.Direction,YaxisPara.RunSpeed,Yaxis,&YaxisPara);
			  PresentStatus.HorizStatus=StartRun;
				SwitchStatus.HorizStatus=NULL;
			}	
		  break;
		case SwitchOff:
			
			Motor_Stop(Yaxis);
			PresentStatus.HorizStatus=StopRun;
			SwitchStatus.HorizStatus=NULL;	
		  break;
	}
	switch(SwitchStatus.VertiStatus)
  {
	  case SwitchOn:
			if(PresentStatus.VertiStatus==StopRun)
			{
				ZaxisPara.RunSpeed=TravelPara.VertiSpeed.ParaValue;
				ZaxisPara.Direction=SwitchSW(SwitchStatus.VertiDir);
				if((ZaxisPara.EdgeStatus>>ZaxisPara.Direction)==0x01) break;
		    MotorSetMmaMove(ZaxisPara.Direction,ZaxisPara.RunSpeed,Zaxis,&ZaxisPara);
			  PresentStatus.VertiStatus=StartRun;
				SwitchStatus.VertiStatus=NULL;
			}	
		  break;
		case SwitchOff:
			
			Motor_Stop(Zaxis);
			PresentStatus.VertiStatus=StopRun;
			SwitchStatus.VertiStatus=NULL;
		  break;
	}
	switch(SwitchStatus.TravelStatus)
  {
	  case SwitchOn:
			if(PresentStatus.TravelStatus==StopRun)
			{
				XaxisPara.RunSpeed=TravelPara.TravelSpeed.ParaValue;
				XaxisPara.Direction=SwitchSW(SwitchStatus.TravelDir);
		    MotorSetMmaMove(XaxisPara.Direction,XaxisPara.RunSpeed,Xaxis,&XaxisPara);
			  PresentStatus.TravelStatus=StartRun;
				SwitchStatus.TravelStatus=NULL;
			}	
		  break;
		case SwitchOff:
			
			Motor_Stop(Xaxis);
			SwitchStatus.TravelStatus=NULL;
			PresentStatus.TravelStatus=StopRun;	
		  break;
	}
	switch(SwitchStatus.OscSwitch)
  {
	  case SwitchOn:
			if(PresentStatus.OscSwitch==NULL)
			{
				SwitchStatus.OscSwitch=NULL;
			  PresentStatus.OscSwitch=StartOsc;
			}	
		  break;
		case SwitchOff:

			SwitchStatus.OscSwitch=NULL;
			PresentStatus.OscSwitch=StopOsc;
		  break;
	}
	switch(SwitchStatus.HorizAdjDir)
	{
		case SwitchLift:
			AdjFlag=Adj_HorizLift;
			OSMboxPost(msg_OscAdj,(void*)AdjFlag);
			SwitchStatus.HorizAdjDir=NULL;
			break;
		case SwitchRight:
			AdjFlag=Adj_HorizRight;
			OSMboxPost(msg_OscAdj,(void*)AdjFlag);
			SwitchStatus.HorizAdjDir=NULL;
			break;
	}	
	switch(SwitchStatus.VertiAdjDir)
	{
		case SwitchUp:
			SwitchStatus.VertiAdjDir=NULL;
			AdjFlag=Adj_HightUp;
			OSMboxPost(msg_HightAdj,(void*)AdjFlag);
			break;
		case SwitchDown:
			SwitchStatus.VertiAdjDir=NULL;
			AdjFlag=Adj_HightDown;
			OSMboxPost(msg_HightAdj,(void*)AdjFlag);
			break;
	}			
	switch(SwitchStatus.WidthAdjDir)
	{
		case SwitchInc:
			AdjFlag=Adj_WidthInc;
			OSMboxPost(msg_OscAdj,(void*)AdjFlag);
			SwitchStatus.WidthAdjDir=NULL;
			break;
		case SwitchDec:
			AdjFlag=Adj_WidthDec;
			OSMboxPost(msg_OscAdj,(void*)AdjFlag);
			SwitchStatus.WidthAdjDir=NULL;
			break;
	}	
}	

static void GetOriginMotion(void)
{
	u8 GetOriginMsg;
	GetOriginMsg=(unsigned char)OSMboxAccept(msg_Origin);
	if(GetOriginMsg!=NULL)
	{	
		YaxisPara.OriginFlag=GetOriginStart;
		ZaxisPara.OriginFlag=GetOriginStart;
		YaxisPara.RunSpeed=YaxisOriginSpeed;
		ZaxisPara.RunSpeed=ZaxisOriginSpeed;
		MotorSetMmaMove(YaxisOriginDir,YaxisOriginSpeed,Yaxis,&YaxisPara);
		MotorSetMmaMove(ZaxisOriginDir,ZaxisOriginSpeed,Zaxis,&ZaxisPara);
	}
	if(YaxisPara.OriginFlag==GetOriginOk)
	{
		PostionInit(Yaxis);
		YaxisPara.OriginFlag=NULL;
	  MotorSetAutoMove(0,YaxisTargetPos,NULL,YaxisOriginSpeed,NULL,Yaxis,&YaxisPara);
	}	
	if(ZaxisPara.OriginFlag==GetOriginOk)
	{
		PostionInit(Zaxis);
		ZaxisPara.OriginFlag=NULL;
	  MotorSetAutoMove(0,ZaxisTargetPos,NULL,ZaxisOriginSpeed,NULL,Zaxis,&ZaxisPara);
	}	
}	

void EdgeSignalDetect(void)
{
  switch(YaxisLedge)
	{
	  case NULL:
			if((YaxisPara.EdgeStatus&Ledge)==Ledge) break;
			YaxisPara.EdgeStatus|=Ledge;
		  Motor_Stop(Yaxis);
		  break;
		case TRUE:
			YaxisPara.EdgeStatus&=~(Ledge);
		  break;
	}	
	switch(YaxisRedge)
	{
	  case NULL:
			if(YaxisPara.OriginFlag==GetOriginStart)
			{
				Motor_Stop(Yaxis);			  
				YaxisPara.OriginFlag=GetOriginOk;
			}	
			if((YaxisPara.EdgeStatus&Redge)==Redge) break;
			YaxisPara.EdgeStatus|=Redge;
		  Motor_Stop(Yaxis);		  		
		  break;
		case TRUE:
			YaxisPara.EdgeStatus&=~(Redge);
		  break;
	}
	switch(ZaxisLedge)
	{
	  case NULL:
			if((ZaxisPara.EdgeStatus&Ledge)==Ledge) break;
			ZaxisPara.EdgeStatus|=Ledge;
		  Motor_Stop(Zaxis);
		  break;
		case TRUE:
			ZaxisPara.EdgeStatus&=~(Ledge);
		  break;
	}
	switch(ZaxisRedge)
	{
	  case NULL:
			if(ZaxisPara.OriginFlag==GetOriginStart)
			{
				Motor_Stop(Zaxis);
				ZaxisPara.OriginFlag=GetOriginOk;
			}
			if((ZaxisPara.EdgeStatus&Redge)==Redge) break;
			ZaxisPara.EdgeStatus|=Redge;
		  Motor_Stop(Zaxis);		  			
		  break;
		case TRUE:
			ZaxisPara.EdgeStatus&=~(Redge);
		  break;
	}
}	

void MotorOperationTask(void)
{			  		
	PosRecordTask();
	GetOriginMotion();
}	

