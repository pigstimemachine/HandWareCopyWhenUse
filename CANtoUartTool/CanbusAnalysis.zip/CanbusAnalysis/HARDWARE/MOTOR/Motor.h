#ifndef _MOTOR_H
#define  _MOTOR_H
#include "sys.h"
#include "math.h"

typedef struct
{
	 int   Offset;
	 float Period;
	 float RunTime;
	 float HoldTime;	
   float SwingFreq;	
	 u32   RunSpeed;
	 u8    Direction;
	 u32   TotalStepNum;      //�ܲ���
	 u32   RemainStepNum;     //���²���
	 u32   RunStepNum;        //���²���
	 u32   SubStepNum;        //�ֲ�����
	 u32   RecordStepNum;     //����
	 u32   RecordTotStepNum;  //��¼�ܲ���
	 u32   PresentTotStepNum; //��ǰ�ܲ���
	 u32   DecStepNum;        //��ʼ���ٲ���
	 u32   DecOffset;
	 u8    ShiftSign;
	 u32   RunFreq;
	 u32   StartFreq;
	 u32   ExecuteFreq;
	 u32   ExecuteSpeed;
	 
	 u32   ACC;
	 u32   AccCopy;
	 u8    Status;
   u8    EdgeStatus;
   u8    OriginFlag;	 
}MOTOR_PARA;


typedef struct
{
	 int   RecordPos;
   int   SourcePos;
   int   TargetPos;
   int   CentrePos;	
	 int   PdLiftPos;
	 int   PdRightPos;
	 int   PresentPos;
	 int   TempSouPos;
	 int   TempTarPos;
}POSTION;

typedef struct
{
	 u32   RecordTick;
   u32   TargetTick;
	 u8    ClockStatus;
	 float HoldTime;
}TICK_COUNT;

typedef struct
{
	 u8 ReciveFlag;
	 u16 ReciveData;
}OSC_TRACK_STRUCT;

typedef struct
{
	 OSC_TRACK_STRUCT OscCtrl;
	 OSC_TRACK_STRUCT HightCtrl;
}OSC_TRACK;

typedef struct
{
   u8  WeldingStatus;
   u8  AutoTrack;
   u8  TravelStatus;
	 u8  TravelDir;
   u8  HorizStatus;
	 u8  HorizDir;
   u8  VertiStatus; 
   u8  VertiDir;	
	 u8  HorizAdjDir;
   u8  VertiAdjDir;
   u8  WidthAdjDir; 
   u8  OscSwitch;	
	 u8  CycleStatus;
}SWITCH_STATUS;

typedef struct
{
   u8  ParaCmd;
	 float ParaValue;
   u16 TransmitValue;
   float paraA;
   float paraB;	
}PARA_STRUCT;

typedef struct
{
   PARA_STRUCT  OscFreq;
   PARA_STRUCT  OscWidth;
	 PARA_STRUCT  HoldTime;
	 PARA_STRUCT  HorizInc;
	 PARA_STRUCT  VertiInc;
   PARA_STRUCT  WidthInc;
	 PARA_STRUCT	TravelSpeed;
	 PARA_STRUCT  HorizSpeed;
	 PARA_STRUCT  VertiSpeed;
   PARA_STRUCT  TravelAdjSpeed;		 
}TRAVEL_PARA;


typedef struct
{
	 u8 TrackErrorCode;
	 u8 SetErrorCode;
}ERROR_FLAG;

extern POSTION    XaxisPos,YaxisPos,ZaxisPos;
extern MOTOR_PARA XaxisPara,YaxisPara,ZaxisPara;
extern TRAVEL_PARA    TravelPara;
extern SWITCH_STATUS  SwitchStatus,PresentStatus;
extern OSC_TRACK     OscTrack;

#define Adj_HorizLift                1
#define Adj_HorizRight               2
#define Adj_WidthInc                 3
#define Adj_WidthDec                 4
#define Adj_HightUp                  1
#define Adj_HightDown                2

#define CoreFreq                 72000000
#define XaxisPW                  100
#define YaxisPW                  100
#define ZaxisPW                  100
#define XaxisPSC                 11
#define YaxisPSC                 11
#define ZaxisPSC                 11
#define XaxisARR                 TIM5->ARR
#define YaxisARR                 TIM3->ARR
#define ZaxisARR                 TIM8->ARR
#define XaxisCCR                 TIM5->CCR4
#define XaxisCapPSC              0
#define YaxisCapPSC              0
#define ZaxisCapPSC              0
#define XaxisCapARR              TIM2->ARR
#define YaxisCapARR              TIM1->ARR
#define ZaxisCapARR              TIM4->ARR
#define XaxisCapSet              TIM2_Capture_Set
#define YaxisCapSet              TIM1_Capture_Set
#define ZaxisCapSet              TIM4_Capture_Set
#define XaxisDIR                 PAout(4) 
#define YaxisDIR                 PCout(4)
#define ZaxisDIR                 PBout(1)
#define XaxisENA                 TIM5->CR1
#define YaxisENA                 TIM3->CR1
#define ZaxisENA                 TIM8->CR1
#define XaxisStepNum             TIM2->CNT
#define YaxisStepNum             TIM1->CNT
#define ZaxisStepNum             TIM4->CNT
#define XaxisBrake               PAout(5)
#define XSWR                     PEin(8)
#define XSWL                     PEin(9)
#define YSWR                     PDin(8)
#define YSWL                     PDin(9)
#define ZSWR                     PDin(10)
#define ZSWL                     PDin(11)
#define MotorSpeed               (int)((float)(6000000/((TIM2->ARR)+1))*((float)((float)(1.8/250)/360))*60)
#define RightDir                 0
#define LiftDir                  1
#define UPDir                    1
#define DOWNDir                  0
#define TvlDir                   0
#define IncDir                   1
#define MotorStart               0
#define MotorStop                1
#define SpeedUp                  0
#define SlowDown                 1
#define SpeedUnit                100
#define Xaxis                    0
#define Yaxis                    1
#define Zaxis                    2
#define MotorEnable              1<<0
#define MotorDisable             ~(1<<0)
#define Infinity                 0xffffffff
#define ClockInit                1
#define ClockWait                2
#define ClockTimeout             3

/*�绡���ٲ���*/
#define Constant              0
#define Accelerate            1
#define Decelerate            2
#define StartArc              1
#define Welding               2
#define StopArc               3
#define StartOsc              1
#define Oscing                2
#define StopOsc               3
#define StartCycle            1
#define StopCycle             0
#define StartRun              1
#define StopRun               0

#define XStepNumRecord        0
#define YStepNumRecord        2000
#define AccDelta              10000

#define MaxAdjSpeed   1000
#define MinAdjSpeed   0
#define MaxLenValue   4000
#define MinLenValue   0

#define SwitchOn          0x5a
#define SwitchOff         0xa5
#define SwitchLift        0x5a
#define SwitchRight       0xa5
#define SwitchUp          0x5a
#define SwitchDown        0xa5
#define SwitchInc         0x5a
#define SwitchDec         0xa5
#define Normal            0x5a
#define Abnormal          0xa5

#define Tim7Freq              1000

#define XaxisCyclestep        200
#define XaxisMicrostep        16
#define XaxisStartFreq        30000   
#define XaxisPitch            500       //0.01mm
#define XaxisAcc              100000    //0.01mm/s2
#define XaxisMaxAcc           200000
#define XaxisUnitFreq         (XaxisCyclestep*XaxisMicrostep)/XaxisPitch
#define XaxisStartSpeed       (((XaxisStartFreq/XaxisCyclestep)*XaxisPitch)/XaxisMicrostep)  //0.01MM/S
#define XaxisTotDistence      100000    //0.01mm   
#define XaixsStartARR         CoreFreq/(XaxisStartFreq*(XaxisPSC+1))-1
#define XedgeStepNum          10
#define XaxisTotStepNum       (XaxisCyclestep*XaxisTotDistence*XaxisMicrostep)/XaxisPitch
	
#define YaxisCyclestep        200
#define YaxisMicrostep        8
#define YaxisStartFreq        1000
#define YaxisPitch            400      //0.01mm
#define YaxisAcc              10000    //0.01mm/s2
#define YaxisMaxAcc           200000
#define YaxisUnitFreq         (YaxisCyclestep*YaxisMicrostep)/YaxisPitch
#define YaxisStartSpeed       (((YaxisStartFreq/YaxisCyclestep)*YaxisPitch)/YaxisMicrostep)  //0.01MM/S
#define YaxisTotDistence      20000    //0.01mm 
#define YaixsStartARR         CoreFreq/(YaxisStartFreq*(YaxisPSC+1))-1
#define YedgeStepNum          10
#define YaxisTotStepNum       (YaxisCyclestep*YaxisTotDistence*YaxisMicrostep)/YaxisPitch

#define ZaxisCyclestep        200
#define ZaxisMicrostep        8
#define ZaxisStartFreq        1000
#define ZaxisPitch            200      //0.01mm  
#define ZaxisAcc              10000   //0.01mm/s2
#define ZaxisMaxAcc           200000
#define ZaxisUnitFreq         (ZaxisCyclestep*ZaxisMicrostep)/ZaxisPitch
#define ZaxisStartSpeed       (((ZaxisStartFreq/ZaxisCyclestep)*ZaxisPitch)/ZaxisMicrostep)  //0.01MM/S
#define ZaxisTotDistence      20000    //0.01mm 
#define ZaixsStartARR         CoreFreq/(ZaxisStartFreq*(ZaxisPSC+1))-1
#define ZedgeStepNum          10
#define ZaxisTotStepNum       (ZaxisCyclestep*ZaxisTotDistence*ZaxisMicrostep)/ZaxisPitch

//////////////////////���ߵ������//////////////////////
#define PI                       3.141592653
#define MaxRspeed                6150                  //���ת��
#define Diameter                 2300                  //����ֱ��(0.01mm)
#define Perimeter                Diameter*PI           //�����ܳ�
#define Ratio                    340                   //���ٱ�

//////////////////////���ؼ��//////////////////////////
#define YaxisLedge               PDin(11)
#define YaxisRedge               PDin(10)
#define ZaxisLedge               PDin(8)
#define ZaxisRedge               PDin(9)

#define YinitOK                  1
#define ZinitOK                  2
#define Redge                    1
#define Ledge                    2

#define YaxisOriginDir           RightDir
#define YaxisOriginSpeed         600
#define YaxisTargetPos           2000
#define ZaxisOriginDir           RightDir
#define ZaxisOriginSpeed         600
#define ZaxisTrackSpeed          800
#define ZaxisTargetPos           2000

#define GetOriginStart           1
#define GetOriginOk              2

#define Osc_Track                0x55
#define Both_Track               0x66
#define Hight_Track              0x77
#define Off_Track                0xaa

#define Flag_OscTrack            1
#define Flag_HightTrack          2
#define Flag_BothTrack           3



void TIM3_PWM_Init(u16 arr,u16 psc);
void TIM5_PWM_Init(u16 arr,u16 psc);   //TIM5_CH3
void TIM8_PWM_Init(u16 arr,u16 psc);  //TIM8_CH1   ����
void TIM2_Capture_Init(u16 arr,u16 psc);
void TIM2_Capture_Set(u16 arr,u8 Sel);
void TIM2_IRQHandler(void);
void TIM1_UP_IRQHandler(void);
void Motor_Init(void);
void Motor_Start(u8 dir,u8 dimension,u32* ReaminStepNum);
void Motor_Stop(u8 dimension);
void MotorShiftTask(void);
void TIM1_Capture_Set(u16 arr,u8 Sel);
void TIM4_Capture_Init(u16 arr,u16 psc);   //���¼���
void TIM4_IRQHandler(void);
void TIM4_Capture_Set(u16 arr,u8 Sel); 
u8 SubCaptureSet(u8 dimension,u32* ReaminStepNum);
u8 AutoSwingTask(void);
u8 SetTimer(TICK_COUNT* HoldTimeCount); 
u8 PostionCall(void);
void Motor_FreqSetting(u8 dimension,u32 Freq);
void TIM1_Capture_Init(u16 arr,u16 psc);
u8 PrintfTest(void);
void MotorOperationTask(void);
u8 StepCounterTask(void) ;
void Motor_SpeedSetting(u32 RunSpeed);
void PosRecordTask(void);
void _SwitchCheckTask(void);
void EdgeSignalDetect(void);
void AutoOscTask(void);

#endif