#ifndef __USART_H
#define __USART_H
#include "stdio.h"
#include "sys.h"
#include "lib.h"	 
//////////////////////////////////////////////////////////////////////////////////	 
typedef struct
{
	u8  StartRev;
	u8  DataLen;
}UART_STATUS;

#define USART1_MAX_RECV_LEN		  1024				               //
#define USART1_MAX_SEND_LEN		  1024				               //
extern u8  USART1_RX_BUF[USART1_MAX_RECV_LEN]; 		//���ջ���,���USART2_MAX_RECV_LEN�ֽ�
extern u8  USART1_TX_BUF[USART1_MAX_SEND_LEN]; 		//���ͻ���,���USART2_MAX_SEND_LEN�ֽ�
extern u16 USART1_RX_STA;   						//��������״̬  	
extern u16 USART1_RX_STA;         		//����״̬���	
void uart_init(u32 pclk2,u32 bound);
void u1_printf(char* fmt,...);
void u1_send(u8* buf,u16 len);
u8 ProtocolAnalysis(u8 DR);
void UartSendTask(void);
void u1_sendbyte(u8 byte);

#endif	   
















